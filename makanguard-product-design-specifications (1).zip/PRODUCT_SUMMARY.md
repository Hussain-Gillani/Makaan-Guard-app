# MakanGuard - Product Summary

## Executive Summary

**MakanGuard** is a mobile application designed to protect Pakistani homeowners from the 25-40% budget overruns that plague residential construction projects due to material theft and fraud. Acting as a "trusted elder brother," it provides calm, vigilant oversight of every aspect of home construction.

---

## Market Opportunity

### Target Market Size
- **800,000 - 1,000,000** houses built annually in Pakistan
- **10+ million** overseas Pakistanis
- **$32-35 billion** in annual remittances
- **Rs. 80 lakh - Rs. 2.5 crore** typical construction budgets

### Problem Statement
1. **Material Theft**: 25-40% budget overruns due to contractor fraud
2. **Zero Visibility**: Overseas Pakistanis have no remote monitoring
3. **Price Volatility**: Material prices fluctuate without homeowner knowledge
4. **No Digital Tools**: Existing apps are contractor-focused, not homeowner-first

### Competition
- **Almost none** in homeowner-first, anti-theft space
- Existing tools: Basic calculators or complex contractor software
- **No diaspora-friendly** solutions with English interface and remote monitoring

---

## Product Vision

### Core Value Proposition
> "Stop losing 25-40% of your construction budget. See everything, know everything, control everything - from anywhere in the world."

### Key Differentiators
1. **Homeowner-First**: Not a contractor tool
2. **Anti-Theft Focus**: Primary goal is fraud prevention
3. **Diaspora-Friendly**: English interface, video calls, weekly collages
4. **Calm Guardian**: Never stressful, always empowering
5. **Offline-First**: Works without internet connection

### Brand Personality
- Protective like a trusted elder brother
- Calm, never alarming
- Respectful of Pakistani culture
- Empowering, not overwhelming
- Professional yet warm

---

## Six-Scope Product Roadmap

### Scope 1: Project Setup & Smart Estimator (19 days)
**Goal**: Get homeowners excited and protected from day one

**Features**:
- 7-8 question guided setup wizard
- Plot size selector (marla/kanal with visual reference)
- Floor count and house type selection
- City-specific material quantity calculation
- Current market rate integration
- Animated house visualization

**Feel**: "Aap ke 10 marla double-storey ghar ke liye 1,850 cement bags lagen ge"

**Acceptance**: User finishes feeling smart and protected with exact quantities and budget

---

### Scope 2: Live Material Rate Tracker & Alerts (22 days)
**Goal**: Help homeowners save money and buy at the right time

**Features**:
- Daily updated prices for cement, steel, sand, bricks
- Brand-specific rates (Lucky, Bestway, DG, Amreli, Mughal)
- Trend arrows and percentage changes
- User-configurable price-drop alerts
- WhatsApp notifications

**Feel**: Like having a knowledgeable friend checking the market daily

**Acceptance**: Users receive "Good news! Cement price dropped 2.3%" alerts

---

### Scope 3: Material Delivery Logging (17 days)
**Goal**: Make logging so fast and easy that everyone does it

**Features**:
- Photo-first flow (stack + invoice)
- Quantity input with voice support (Urdu)
- Auto GPS tagging
- Offline support with sync
- Under 30 seconds to complete
- Green confirmation in Urdu

**Feel**: Quick, official, and satisfying

**Acceptance**: Even elderly parents or site helpers can use it easily

---

### Scope 4: Daily Usage Logging & Anti-Theft Engine (21 days)
**Goal**: Silently detect theft and empower owners to take action

**Features**:
- Contractor daily usage logging (voice input)
- Background discrepancy detection engine
- Private owner-only alerts
- Evidence presentation (photos, quantities, dates)
- Suggested respectful next actions
- Calm, non-accusatory notifications

**Feel**: Quietly vigilant watchdog

**Acceptance**: Owner discovers 15-bag cement discrepancy and addresses it calmly

---

### Scope 5: Progress Photo Journal & Overseas Dashboard (21 days)
**Goal**: Make overseas Pakistanis feel connected to their dream home

**Features**:
- 4-5 daily geo-tagged photos with captions
- Voice caption support
- Daily photo digests
- Weekly collages (family album style)
- English-first overseas dashboard
- One-tap video call to supervisor
- Timezone-aware notifications

**Feel**: "Mera ghar ban raha hai aur mujhe sab kuch dikhai de raha hai"

**Acceptance**: Overseas user shows weekly collage to friends with pride

---

### Scope 6: Premium Monitoring, Payments & Supplier Connections (46 days)
**Goal**: Convert free users to paying subscribers after proving value

**Features**:
- Monthly subscription ($15-25 overseas, Rs. 3K-5K local)
- Milestone verification (photos + material proof required)
- Payment release via JazzCash/Easypaisa
- One-tap supplier ordering with pre-filled quantities
- Trusted supplier network
- Full anti-theft monitoring

**Feel**: Like hiring a professional engineer to watch full-time

**Acceptance**: User pays $20/month gladly, feels it's worth 100x the cost

---

## Technical Architecture

### Mobile App
- **React Native** (iOS + Android)
- **TypeScript** for type safety
- **SQLite** for offline storage
- **Redux** for state management

### Backend
- **Node.js + Express** API server
- **PostgreSQL** primary database
- **Redis** caching layer
- **Socket.io** for real-time updates
- **AWS S3** photo storage
- **CloudFront** CDN

### Key Technical Features
1. **Offline-First**: Full functionality without internet
2. **Real-Time Sync**: Instant updates via WebSockets
3. **Photo Compression**: Automatic optimization
4. **GPS Watermarking**: All photos timestamped and geotagged
5. **End-to-End Encryption**: AES-256 at rest, TLS 1.3 in transit

---

## Security & Access Control

### Authentication
- JWT token-based auth
- SMS OTP via JazzCash/Easypaisa
- Multi-factor for sensitive actions
- Session management with auto-logout

### Role-Based Permissions

| Feature | Owner | Contractor | Supervisor |
|---------|-------|------------|------------|
| View Budget | ✅ | ❌ | ❌ |
| Log Deliveries | ✅ | ✅ | ✅ |
| Log Usage | ❌ | ✅ | ✅ |
| View Alerts | ✅ | ❌ | ✅ |
| Release Payments | ✅ | ❌ | ❌ |
| Invite Users | ✅ | ❌ | ❌ |

### Data Protection
- All photos watermarked (never shareable publicly)
- PII fully encrypted
- Phone numbers and addresses protected
- Audit trail for every action
- 30-day backup retention

---

## Monetization Strategy

### Free Tier
- Project setup and estimates
- Basic delivery logging
- Price tracking (view only)
- Limited to 1 project
- Photo storage (100 photos)

### Premium Tier
**Overseas**: $15-25/month  
**Local**: Rs. 3,000-5,000/month

**Includes**:
- Unlimited projects
- Full anti-theft engine with alerts
- Milestone verification
- Payment integration
- Unlimited photo storage
- Weekly collages
- Priority support
- Video call feature

### Revenue Projections (Year 1)
- **Target**: 10,000 free users → 1,500 paid (15% conversion)
- **Average**: $20/month
- **MRR**: $30,000
- **ARR**: $360,000

### Future Revenue Streams
1. **Supplier Commissions**: 2-3% on material orders
2. **Contractor Verification**: Background check service
3. **Insurance**: Partner with home insurance providers
4. **Enterprise**: Construction companies licensing platform

---

## Go-to-Market Strategy

### Phase 1: Overseas Pakistanis (Months 1-3)
- **Channels**: Facebook groups, WhatsApp, expat community events
- **Messaging**: "See your house being built from anywhere in the world"
- **Pricing**: $15/month trial for first 100 users

### Phase 2: Local Homeowners (Months 4-6)
- **Channels**: Construction material shops, civil engineers, word of mouth
- **Messaging**: "Ap ki jeb se 30 lakh rupay bach sakte hain"
- **Pricing**: Rs. 3,000/month

### Phase 3: Scale (Months 7-12)
- **Channels**: TV ads, influencer marketing, referral program
- **Messaging**: "Pakistan ka #1 ghar banane ka digital guardian"
- **Pricing**: Tiered plans, family plans

---

## Success Metrics

### Product KPIs
1. **Theft Detection**: Average 18% budget saved per project
2. **Engagement**: Daily active usage 65%+
3. **Overseas Retention**: 80%+ monthly retention
4. **Local Retention**: 60%+ monthly retention
5. **NPS Score**: 70+ (world-class)

### Business KPIs
1. **Free → Paid Conversion**: 15%+ within 30 days
2. **CAC**: <$50 via organic + referrals
3. **LTV**: $300+ (15 months average)
4. **LTV:CAC Ratio**: 6:1+
5. **Viral Coefficient**: 1.3+ (each user brings 1.3 new users)

---

## Competitive Advantages

### Unique Moats
1. **Trust**: First-mover in homeowner anti-theft space
2. **Data**: Proprietary material usage benchmarks
3. **Network Effects**: More users → better price data
4. **Brand**: "Trusted guardian" positioning
5. **Switching Costs**: Mid-project migration painful

### Barriers to Entry
- **Cultural Understanding**: Deep knowledge of Pakistani construction
- **Local Partnerships**: JazzCash, Easypaisa, suppliers
- **Engineering**: Offline-first architecture is complex
- **Brand**: Trust takes years to build

---

## Risk Mitigation

### Technical Risks
- **Offline sync conflicts**: Queue-based resolution with timestamps
- **Photo storage costs**: Aggressive compression, S3 lifecycle policies
- **Scalability**: Horizontal scaling, Redis caching, CDN

### Business Risks
- **Low adoption**: Free tier with immediate value to drive usage
- **Contractor resistance**: Respectful UI, emphasize efficiency not surveillance
- **Payment failures**: Multiple payment methods, retry logic

### Market Risks
- **Economic downturn**: Lower pricing tier, flexible plans
- **Regulatory**: Compliance with data privacy laws
- **Competition**: Strong brand moat, network effects

---

## Development Timeline

### Total: 172 days (~6 months with 3-person team)

| Scope | Duration | Tickets |
|-------|----------|---------|
| Scope 1 | 19 days | 3 |
| Scope 2 | 22 days | 3 |
| Scope 3 | 17 days | 3 |
| Scope 4 | 21 days | 3 |
| Scope 5 | 21 days | 3 |
| Scope 6 | 46 days | 4 |

**Parallel Development**:
- Frontend + Backend teams working simultaneously
- Launch MVP (Scopes 1-3) in 3 months
- Full product in 6 months

---

## Team Requirements

### Core Team
1. **Product Manager** (1) - Vision, roadmap, user research
2. **Lead Engineer** (1) - Architecture, backend
3. **Mobile Developer** (1) - React Native, frontend
4. **Designer** (0.5) - UI/UX, brand
5. **QA Engineer** (0.5) - Testing, quality

### Future Hires (Month 6+)
- Customer Success Manager
- Growth/Marketing Lead
- Additional Engineers (2-3)

---

## Key Partnerships

### Required for Launch
1. **JazzCash** - Payment integration, SMS OTP
2. **Easypaisa** - Alternative payment method
3. **WhatsApp Business API** - Notifications
4. **Google Maps API** - GPS, location services

### Nice-to-Have
1. **Major Cement Companies** - Official price feeds
2. **Steel Manufacturers** - Market rate data
3. **Construction Suppliers** - Verified network
4. **Insurance Companies** - Bundle offerings

---

## Conclusion

MakanGuard addresses a massive, underserved market with a product that delivers immediate, tangible value. By focusing on homeowner empowerment and anti-theft protection, it creates a defensible business with strong unit economics and viral growth potential.

The six-scope roadmap allows for iterative development, early validation, and rapid time-to-market. With the right execution, MakanGuard can become the standard tool for residential construction in Pakistan and eventually expand to similar markets across South Asia and beyond.

---

**Next Steps**:
1. Validate demand with 50 user interviews
2. Build MVP (Scopes 1-3) in 3 months
3. Launch beta with 100 overseas users
4. Iterate based on feedback
5. Scale to 10,000 users in Year 1
