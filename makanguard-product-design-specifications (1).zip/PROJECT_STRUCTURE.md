# MakanGuard - Project Structure

## 📁 Directory Overview

```
makanguard-interactive-demo/
├── src/
│   ├── app/                      # Next.js App Router
│   │   ├── api/                  # API routes
│   │   │   └── health/          # Health check endpoint
│   │   │       └── route.ts
│   │   ├── globals.css          # Global styles & Tailwind
│   │   ├── layout.tsx           # Root layout
│   │   └── page.tsx             # Main application page
│   │
│   ├── components/              # React components
│   │   ├── PRDView.tsx         # Product Requirements Document
│   │   ├── UserFlowView.tsx    # User journey flows
│   │   ├── ScreensView.tsx     # Interactive mockups
│   │   ├── TechnicalArchitecture.tsx  # System design
│   │   ├── SecurityView.tsx    # Security & access control
│   │   ├── FrontendSpecs.tsx   # Design system specs
│   │   └── FeatureTickets.tsx  # Development roadmap
│   │
│   └── db/                      # Database
│       ├── index.ts            # Database client
│       └── schema.ts           # Drizzle ORM schema
│
├── public/                      # Static assets (none currently)
├── .env                        # Environment variables
├── drizzle.config.json         # Drizzle configuration
├── next.config.ts              # Next.js configuration
├── package.json                # Dependencies
├── postcss.config.mjs          # PostCSS config
├── tailwind.config.js          # Tailwind CSS config
├── tsconfig.json               # TypeScript config
│
└── Documentation/
    ├── README.md              # Main project README
    ├── QUICK_START.md         # Quick start guide
    ├── PRODUCT_SUMMARY.md     # Executive summary
    ├── FEATURES.md            # Feature documentation
    └── PROJECT_STRUCTURE.md   # This file
```

## 🎯 Key Files Explained

### Application Core

#### `src/app/page.tsx` (Main Application)
- **Purpose**: Main entry point with navigation
- **Features**:
  - Tab-based navigation system
  - Mobile responsive menu
  - Animated background effects
  - View state management
  - Header and footer components

#### `src/app/layout.tsx` (Root Layout)
- **Purpose**: App-wide layout and metadata
- **Features**:
  - HTML structure
  - Global metadata (title, description)
  - Font loading
  - Body styling

#### `src/app/globals.css` (Global Styles)
- **Purpose**: Tailwind CSS and global styles
- **Includes**:
  - Tailwind directives
  - Custom CSS variables
  - Base styles
  - Utility classes

### View Components

#### `src/components/PRDView.tsx`
**Product Requirements Document**
- Product vision and mission
- Market statistics (800K-1M houses/year)
- 6 sequential scopes breakdown
- Core principles (what it is/isn't)
- Key features per scope

**Data Structures**:
```typescript
scopes: Array<{
  id: number;
  title: string;
  description: string;
  feel: string;
  keyFeatures: string[];
  icon: LucideIcon;
  color: string;
}>
```

#### `src/components/UserFlowView.tsx`
**User Journey Mapping**
- 3 user personas (Homeowner, Overseas, Contractor)
- Step-by-step flows per persona
- Duration estimates
- Detailed task breakdowns

**Data Structures**:
```typescript
flows: Record<UserPersona, Array<{
  step: number;
  title: string;
  description: string;
  duration: string;
  icon: LucideIcon;
  details: string[];
}>>
```

#### `src/components/ScreensView.tsx`
**Interactive Screen Mockups**
- Phone frame mockup
- 6 screen types (onboarding, dashboard, etc.)
- Interactive form elements
- Realistic UI components

**Screens**:
- `DashboardScreen` - Home overview
- `OnboardingScreen` - Setup wizard
- `EstimateScreen` - Material calculations
- `DeliveryScreen` - Photo logging
- `PricingScreen` - Live rates
- `AlertsScreen` - Notifications

#### `src/components/TechnicalArchitecture.tsx`
**System Design Documentation**
- Tech stack breakdown (frontend, backend, infra)
- System layer diagrams
- Data flow visualization
- Database schema overview
- Performance metrics

**Data Structures**:
```typescript
techStack: {
  frontend: TechItem[];
  backend: TechItem[];
  infrastructure: TechItem[];
  integrations: TechItem[];
}
```

#### `src/components/SecurityView.tsx`
**Security & Access Control**
- 4 security layers
- Threat mitigation strategies
- Access control matrix
- Compliance standards
- Privacy principles

**Features**:
- Role-based permission table
- Security measure cards
- Threat severity indicators
- Compliance badges

#### `src/components/FrontendSpecs.tsx`
**Design System Specifications**
- Color palette (primary, semantic, neutral)
- Typography scale
- Component library
- Animation specifications
- Responsive breakpoints
- Accessibility standards

**Design Tokens**:
```typescript
colorPalette: {
  primary: ColorSpec[];
  semantic: ColorSpec[];
  neutral: ColorSpec[];
}
```

#### `src/components/FeatureTickets.tsx`
**Development Roadmap**
- 28 detailed feature tickets
- Organized by scope (1-6)
- Priority levels (critical, high, medium, low)
- Status tracking (planned, in progress, completed)
- Acceptance criteria
- Dependencies
- Time estimates

**Data Model**:
```typescript
Ticket: {
  id: string;
  scope: number;
  title: string;
  description: string;
  priority: Priority;
  status: Status;
  estimatedDays: number;
  dependencies?: string[];
  acceptanceCriteria: string[];
}
```

### Database

#### `src/db/schema.ts`
**Database Schema Definitions**

**Tables**:
1. `projects` - Core project data
2. `material_estimates` - Calculated quantities
3. `deliveries` - Material delivery logs
4. `usage_logs` - Daily usage tracking
5. `progress_photos` - Construction photos
6. `alerts` - Discrepancy notifications
7. `feature_tickets` - Development roadmap (demo data)

**Example Schema**:
```typescript
export const projects = pgTable('projects', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  plotSize: decimal('plot_size').notNull(),
  floors: integer('floors').notNull(),
  city: text('city').notNull(),
  // ... more fields
});
```

#### `src/db/index.ts`
**Database Client**
- Drizzle ORM initialization
- PostgreSQL connection
- Environment configuration

### API Routes

#### `src/app/api/health/route.ts`
**Health Check Endpoint**
- Database connectivity test
- Returns `{ ok: true }` on success
- Used by platform validation

## 🎨 Styling Architecture

### Tailwind CSS Configuration

**Color System**:
- Primary: `emerald-*`, `teal-*`
- Background: `slate-950`
- Accents: `rose-*`, `amber-*`, `blue-*`, `purple-*`

**Spacing Scale**:
- Base unit: 4px
- Scale: 0, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64

**Typography**:
- Font family: Inter (system fallback)
- Sizes: text-xs to text-7xl
- Weights: 400, 500, 600, 700

### Animation System

**Framer Motion**:
```typescript
// Page transitions
initial={{ opacity: 0, y: 20 }}
animate={{ opacity: 1, y: 0 }}
exit={{ opacity: 0, y: -20 }}
transition={{ duration: 0.4 }}

// Hover effects
whileHover={{ scale: 1.05 }}
whileTap={{ scale: 0.95 }}
```

## 🔧 Configuration Files

### `next.config.ts`
- TypeScript Next.js configuration
- Build settings
- Environment variables

### `tailwind.config.js`
- Design tokens
- Theme extensions
- Plugin configuration

### `tsconfig.json`
- TypeScript compiler options
- Path aliases (`@/*`)
- Module resolution

### `drizzle.config.json`
- Database connection
- Schema location
- Migration settings

### `package.json`
**Key Dependencies**:
- `next@16.2.6` - React framework
- `react@19.2.6` - UI library
- `framer-motion@*` - Animations
- `drizzle-orm@0.45.2` - Database ORM
- `tailwindcss@4.1.17` - Styling

**Scripts**:
- `dev` - Development server
- `build` - Production build
- `start` - Production server
- `typecheck` - TypeScript validation

## 📊 Data Flow

### Component Hierarchy
```
App (page.tsx)
├── Header
│   ├── Logo
│   └── Navigation
│       ├── Desktop Menu
│       └── Mobile Menu
│
├── Main Content
│   └── Current View Component
│       ├── PRDView
│       ├── UserFlowView
│       ├── ScreensView
│       ├── TechnicalArchitecture
│       ├── SecurityView
│       ├── FrontendSpecs
│       └── FeatureTickets
│
└── Footer
```

### State Management
```typescript
// Main app state
const [currentView, setCurrentView] = useState<ViewType>('prd');
const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

// Feature tickets state
const [selectedScope, setSelectedScope] = useState<number | null>(null);
const [selectedStatus, setSelectedStatus] = useState<Status | null>(null);

// User flow state
const [selectedPersona, setSelectedPersona] = useState<UserPersona>('homeowner');

// Screens state
const [activeScreen, setActiveScreen] = useState<ScreenType>('dashboard');
```

## 🎯 Component Patterns

### Card Component Pattern
```typescript
<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6"
>
  {/* Content */}
</motion.div>
```

### Icon with Gradient Background
```typescript
<div className={`w-12 h-12 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center`}>
  <Icon className="w-6 h-6 text-white" />
</div>
```

### Staggered List Animation
```typescript
{items.map((item, index) => (
  <motion.div
    key={item.id}
    initial={{ opacity: 0, x: -10 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: index * 0.1 }}
  >
    {/* Item content */}
  </motion.div>
))}
```

## 📱 Responsive Patterns

### Grid System
```typescript
// Mobile-first responsive grid
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
  {/* Items */}
</div>
```

### Conditional Rendering
```typescript
// Desktop vs Mobile
<nav className="hidden lg:flex"> {/* Desktop */}
<button className="lg:hidden"> {/* Mobile */}
```

## 🚀 Performance Optimizations

### Code Splitting
- Each view component is a separate module
- Lazy loading with React Suspense (future)
- Dynamic imports for heavy components

### Static Generation
- Main page pre-rendered at build time
- Fast initial page load
- CDN-friendly

### Asset Optimization
- SVG icons (no raster images)
- Inline critical CSS
- Minified production bundle

## 🔍 Development Workflow

### Adding a New View
1. Create component in `src/components/`
2. Import in `src/app/page.tsx`
3. Add to navigation items array
4. Add route in main switch statement

### Adding a New Database Table
1. Define schema in `src/db/schema.ts`
2. Run `npx drizzle-kit push`
3. Create API route if needed
4. Update TypeScript types

### Styling Guidelines
- Use Tailwind utility classes
- Follow existing color palette
- Maintain consistent spacing (4px base)
- Add hover states to interactive elements
- Use Framer Motion for animations

## 📚 Documentation Standards

### Code Comments
```typescript
// Brief description of purpose
// Usage example if complex
```

### Component Documentation
```typescript
/**
 * PRDView - Product Requirements Document view
 * 
 * Displays complete product vision, market analysis,
 * and 6-scope roadmap for MakanGuard.
 */
export default function PRDView() { ... }
```

### Type Definitions
```typescript
type ViewType = 'prd' | 'userflow' | 'screens' | ...;

interface Ticket {
  id: string;
  scope: number;
  // ... more fields
}
```

## 🎯 Best Practices

### Performance
- ✅ Use `const` for component data
- ✅ Memoize expensive calculations
- ✅ Lazy load images (if added)
- ✅ Code split large components

### Accessibility
- ✅ Semantic HTML (`<button>`, `<nav>`, etc.)
- ✅ ARIA labels where needed
- ✅ Keyboard navigation support
- ✅ High contrast colors

### Code Quality
- ✅ TypeScript for type safety
- ✅ Consistent naming conventions
- ✅ Component composition
- ✅ DRY (Don't Repeat Yourself)

---

**This structure enables rapid development while maintaining code quality and performance.**
