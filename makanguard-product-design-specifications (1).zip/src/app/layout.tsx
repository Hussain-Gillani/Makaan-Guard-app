import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "MakanGuard - Digital Guardian for Homebuilders",
  description: "Interactive product requirements, user flows, and technical architecture for MakanGuard - protecting Pakistani homeowners from construction theft and fraud",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
