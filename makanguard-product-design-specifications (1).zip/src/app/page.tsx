'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home as HomeIcon, Shield, TrendingDown, Package, Camera, Crown,
  FileText, Users, Lock, Cpu, Layers, CheckCircle2,
  ArrowRight, Menu, X, Building2, AlertTriangle,
  Clock, DollarSign, MapPin, Phone
} from 'lucide-react';

// Import components
import PRDView from '@/components/PRDView';
import UserFlowView from '@/components/UserFlowView';
import ScreensView from '@/components/ScreensView';
import TechnicalArchitecture from '@/components/TechnicalArchitecture';
import SecurityView from '@/components/SecurityView';
import FrontendSpecs from '@/components/FrontendSpecs';
import FeatureTickets from '@/components/FeatureTickets';
import AIFeaturesView from '@/components/AIFeaturesView';
import PaymentView from '@/components/PaymentView';
import RevenueView from '@/components/RevenueView';
import HeroSection from '@/components/HeroSection';

type ViewType = 'prd' | 'userflow' | 'screens' | 'architecture' | 'security' | 'frontend' | 'tickets' | 'ai' | 'payment' | 'revenue';

const navigationItems = [
  { id: 'prd' as ViewType, label: 'PRD', icon: FileText, color: 'from-blue-500 to-cyan-500' },
  { id: 'ai' as ViewType, label: 'AI Features', icon: Building2, color: 'from-purple-500 to-pink-500', highlight: true },
  { id: 'payment' as ViewType, label: 'Payment', icon: DollarSign, color: 'from-emerald-500 to-teal-500', highlight: true },
  { id: 'revenue' as ViewType, label: 'Revenue', icon: TrendingDown, color: 'from-green-500 to-emerald-500', highlight: true },
  { id: 'userflow' as ViewType, label: 'User Flow', icon: Users, color: 'from-indigo-500 to-purple-500' },
  { id: 'screens' as ViewType, label: 'Screens', icon: Layers, color: 'from-cyan-500 to-blue-500' },
  { id: 'architecture' as ViewType, label: 'Architecture', icon: Cpu, color: 'from-orange-500 to-red-500' },
  { id: 'security' as ViewType, label: 'Security', icon: Lock, color: 'from-red-500 to-rose-500' },
  { id: 'frontend' as ViewType, label: 'Frontend', icon: Layers, color: 'from-pink-500 to-purple-500' },
  { id: 'tickets' as ViewType, label: 'Feature Tickets', icon: CheckCircle2, color: 'from-teal-500 to-cyan-500' },
];

export default function Home() {
  const [currentView, setCurrentView] = useState<ViewType>('prd');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showHero, setShowHero] = useState(true);

  return (
    <>
      {showHero && (
        <HeroSection 
          onClose={() => setShowHero(false)} 
          onNavigate={(view) => setCurrentView(view as ViewType)}
        />
      )}
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-emerald-500/5 to-transparent rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        <motion.div
          className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-blue-500/5 to-transparent rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [90, 0, 90],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* Header */}
      <header className="relative border-b border-white/10 backdrop-blur-xl bg-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <motion.div 
              className="flex items-center space-x-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <motion.div
                className="relative"
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/50">
                  <Shield className="w-6 h-6 text-white" />
                </div>
              </motion.div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-emerald-300 to-teal-300 bg-clip-text text-transparent">
                  MakanGuard
                </h1>
                <p className="text-xs text-slate-400">Digital Guardian for Homebuilders</p>
              </div>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-1">
              {navigationItems.map((item, index) => (
                <motion.button
                  key={item.id}
                  onClick={() => setCurrentView(item.id)}
                  className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    currentView === item.id
                      ? 'bg-white/10 text-white shadow-lg'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  } ${'highlight' in item && item.highlight ? 'ring-2 ring-emerald-500/30' : ''}`}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {'highlight' in item && item.highlight && (
                    <motion.div
                      className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    />
                  )}
                  <item.icon className="w-4 h-4 inline mr-2" />
                  {item.label}
                </motion.button>
              ))}
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-400 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden border-t border-white/10 bg-slate-900/95 backdrop-blur-xl"
            >
              <div className="px-4 py-3 space-y-1">
                {navigationItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentView(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                      currentView === item.id
                        ? 'bg-white/10 text-white'
                        : 'text-slate-400 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="relative">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
            className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"
          >
            {currentView === 'prd' && <PRDView />}
            {currentView === 'ai' && <AIFeaturesView />}
            {currentView === 'payment' && <PaymentView />}
            {currentView === 'revenue' && <RevenueView />}
            {currentView === 'userflow' && <UserFlowView />}
            {currentView === 'screens' && <ScreensView />}
            {currentView === 'architecture' && <TechnicalArchitecture />}
            {currentView === 'security' && <SecurityView />}
            {currentView === 'frontend' && <FrontendSpecs />}
            {currentView === 'tickets' && <FeatureTickets />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="relative border-t border-white/10 backdrop-blur-xl bg-white/5 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="text-slate-400 text-sm">
              © 2026 MakanGuard. Protecting your dream home, one brick at a time.
            </p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-xs text-slate-500">Built with Claude Sonnet 4</span>
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            </div>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
}
