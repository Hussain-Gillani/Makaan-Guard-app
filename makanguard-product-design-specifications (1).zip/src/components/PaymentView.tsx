'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { CreditCard, Smartphone, Zap, Shield, CheckCircle2, Copy, ExternalLink, Sparkles, Crown, Award, Star } from 'lucide-react';
import PayAsYouGoView from './PayAsYouGoView';

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    currency: 'Rs.',
    period: 'month',
    description: 'Perfect for getting started',
    icon: Zap,
    color: 'from-blue-500 to-cyan-500',
    features: [
      '1 active project',
      'Basic material estimator',
      '2 AI estimates (one-time)',
      '20 chatbot messages (one-time)',
      '5 photo analyses (one-time)',
      '50 voice commands (one-time)',
      'Basic delivery logging',
      'Price viewing only',
      '50 photos storage',
      'Email support',
    ],
    limitations: [
      'No theft detection AI',
      'No unlimited AI features',
      'No price predictions',
      'No AI scheduler',
      'No document analysis',
      'Limited trial only',
    ],
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 5999,
    currency: 'Rs.',
    period: 'month',
    description: 'Full protection with AI',
    icon: Crown,
    color: 'from-purple-500 to-pink-500',
    popular: true,
    features: [
      'Unlimited projects',
      'All 8 AI features unlocked',
      'Unlimited AI estimates',
      'Unlimited chatbot conversations',
      'Advanced AI theft detection',
      'Real-time AI fraud alerts',
      'Unlimited AI photo analysis',
      'AI price predictions',
      'AI construction scheduler',
      'AI document analyzer',
      'Voice assistant unlimited',
      'Milestone verification',
      'JazzCash/Easypaisa payments',
      'Weekly photo collages',
      'Video call support',
      'Priority 24/7 support',
      'WhatsApp notifications',
      'Export detailed reports',
    ],
    savings: 'Save Rs. 50,000+ on theft prevention',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 15999,
    currency: 'Rs.',
    period: 'month',
    description: 'For construction companies',
    icon: Award,
    color: 'from-orange-500 to-red-500',
    features: [
      'Everything in Premium',
      'Unlimited team members',
      'Multi-project dashboard',
      'Custom AI model training',
      'White-label option',
      'API access',
      'Dedicated account manager',
      'On-site training',
      'Custom integrations',
      'SLA guarantees',
      'Advanced analytics',
      'Bulk supplier discounts',
    ],
    savings: 'Save Rs. 100,000+ annually',
  },
];

const paymentMethods = [
  {
    id: 'nayapay',
    name: 'NayaPay',
    description: 'Direct bank transfer via NayaPay',
    icon: Smartphone,
    recommended: true,
    details: {
      accountName: 'Hussain Gillani',
      accountNumber: '+92 300061971',
      type: 'NayaPay Account',
    },
  },
  {
    id: 'jazzcash',
    name: 'JazzCash',
    description: 'Mobile wallet payment',
    icon: Smartphone,
    details: {
      accountNumber: '+92 300061971',
      type: 'JazzCash Wallet',
    },
  },
  {
    id: 'easypaisa',
    name: 'Easypaisa',
    description: 'Mobile wallet payment',
    icon: Smartphone,
    details: {
      accountNumber: '+92 300061971',
      type: 'Easypaisa Wallet',
    },
  },
];

export default function PaymentView() {
  const [selectedPlan, setSelectedPlan] = useState('premium');
  const [selectedMethod, setSelectedMethod] = useState('nayapay');
  const [copied, setCopied] = useState(false);

  const plan = plans.find(p => p.id === selectedPlan) || plans[1];
  const method = paymentMethods.find(m => m.id === selectedMethod) || paymentMethods[0];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <CreditCard className="w-4 h-4 text-emerald-400" />
          <span className="text-sm text-emerald-400 font-medium">Pricing & Payment</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-emerald-300 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
          Choose Your Plan
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Protect your construction investment with AI-powered monitoring and anti-theft features
        </p>
      </div>

      {/* Pricing Plans */}
      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((planItem, index) => (
          <motion.button
            key={planItem.id}
            onClick={() => setSelectedPlan(planItem.id)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`relative p-6 rounded-3xl border transition-all text-left ${
              selectedPlan === planItem.id
                ? 'bg-white/10 border-white/20 shadow-2xl scale-105'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            } ${planItem.popular ? 'md:scale-110 z-10' : ''}`}
            whileHover={{ scale: planItem.popular ? 1.12 : 1.02 }}
          >
            {planItem.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <div className="px-4 py-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full text-xs font-semibold text-white flex items-center space-x-1">
                  <Star className="w-3 h-3" />
                  <span>MOST POPULAR</span>
                </div>
              </div>
            )}

            <div className={`w-14 h-14 bg-gradient-to-br ${planItem.color} rounded-2xl flex items-center justify-center mb-4`}>
              <planItem.icon className="w-7 h-7 text-white" />
            </div>

            <h3 className="text-2xl font-bold text-white mb-2">{planItem.name}</h3>
            <p className="text-sm text-slate-400 mb-4">{planItem.description}</p>

            <div className="mb-6">
              <div className="flex items-baseline space-x-1">
                <span className="text-4xl font-bold text-white">{planItem.currency}{planItem.price.toLocaleString()}</span>
                <span className="text-slate-400">/{planItem.period}</span>
              </div>
              {planItem.savings && (
                <div className="text-sm text-emerald-400 mt-1">{planItem.savings}</div>
              )}
            </div>

            <div className="space-y-2 mb-6">
              {planItem.features.map((feature, i) => (
                <div key={i} className="flex items-start space-x-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-300">{feature}</span>
                </div>
              ))}
              {planItem.limitations?.map((limitation, i) => (
                <div key={i} className="flex items-start space-x-2 text-sm opacity-50">
                  <div className="w-4 h-4 border-2 border-slate-600 rounded-full flex-shrink-0 mt-0.5" />
                  <span className="text-slate-500 line-through">{limitation}</span>
                </div>
              ))}
            </div>

            {selectedPlan === planItem.id && planItem.id !== 'free' && (
              <motion.div
                layoutId="selectedPlan"
                className="absolute inset-0 border-2 border-emerald-500 rounded-3xl pointer-events-none"
                initial={false}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
          </motion.button>
        ))}
      </div>

      {selectedPlan !== 'free' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12"
        >
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Payment Information</h2>

          {/* Payment Method Selection */}
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            {paymentMethods.map((methodItem) => (
              <button
                key={methodItem.id}
                onClick={() => setSelectedMethod(methodItem.id)}
                className={`p-4 rounded-2xl border transition-all ${
                  selectedMethod === methodItem.id
                    ? 'bg-white/10 border-emerald-500/50 shadow-lg'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    selectedMethod === methodItem.id ? 'bg-emerald-500/20' : 'bg-white/10'
                  }`}>
                    <methodItem.icon className={`w-6 h-6 ${
                      selectedMethod === methodItem.id ? 'text-emerald-400' : 'text-slate-400'
                    }`} />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="flex items-center space-x-2">
                      <span className="text-white font-semibold">{methodItem.name}</span>
                      {methodItem.recommended && (
                        <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/30 rounded text-xs text-emerald-400">
                          Recommended
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">{methodItem.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Payment Details */}
          <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/30 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Payment Details</h3>
              <Shield className="w-6 h-6 text-emerald-400" />
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl">
                <span className="text-slate-400">Selected Plan</span>
                <span className="text-white font-semibold">{plan.name}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl">
                <span className="text-slate-400">Amount</span>
                <span className="text-2xl font-bold text-emerald-400">
                  {plan.currency}{plan.price.toLocaleString()}/{plan.period}
                </span>
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-semibold text-emerald-400">Transfer To:</span>
                <span className="text-xs text-slate-400">{method.details.type}</span>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Account Name</label>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white font-semibold">{method.details.accountName || 'Hussain Gillani'}</span>
                    <button
                      onClick={() => copyToClipboard(method.details.accountName || 'Hussain Gillani')}
                      className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                    >
                      {copied ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-slate-400" />
                      )}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">
                    {method.id === 'nayapay' ? 'NayaPay Number' : 'Mobile Number'}
                  </label>
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <span className="text-white font-mono text-lg">{method.details.accountNumber}</span>
                    <button
                      onClick={() => copyToClipboard(method.details.accountNumber)}
                      className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                    >
                      {copied ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-slate-400" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 mb-6">
              <h4 className="text-sm font-semibold text-amber-400 mb-2">Payment Instructions:</h4>
              <ol className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start space-x-2">
                  <span className="text-amber-400 font-semibold">1.</span>
                  <span>Transfer Rs. {plan.price.toLocaleString()} to the {method.name} number above</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-amber-400 font-semibold">2.</span>
                  <span>Take a screenshot of the payment confirmation</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-amber-400 font-semibold">3.</span>
                  <span>Send the screenshot to +92 300061971 via WhatsApp</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-amber-400 font-semibold">4.</span>
                  <span>Your premium account will be activated within 2 hours</span>
                </li>
              </ol>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <motion.button
                className="flex-1 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold shadow-lg shadow-emerald-500/50"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => window.open('https://wa.me/923000619771?text=Hi! I want to activate MakanGuard Premium', '_blank')}
              >
                <div className="flex items-center justify-center space-x-2">
                  <ExternalLink className="w-5 h-5" />
                  <span>Send Payment Proof via WhatsApp</span>
                </div>
              </motion.button>
            </div>

            <div className="text-center mt-4 text-xs text-slate-500">
              <Shield className="w-4 h-4 inline mr-1" />
              Your payment is secure. We use bank-grade security.
            </div>
          </div>

          {/* What You Get */}
          <div className="bg-white/5 rounded-2xl p-6">
            <h4 className="text-lg font-semibold text-white mb-4">What You Get Immediately:</h4>
            <div className="grid md:grid-cols-2 gap-3">
              {[
                'All 8 AI features unlocked instantly',
                'Unlimited material estimates',
                'Real-time theft detection',
                'Unlimited photo analysis',
                'Priority 24/7 support',
                'WhatsApp notifications',
                'Weekly progress collages',
                'Export detailed reports',
              ].map((item, i) => (
                <div key={i} className="flex items-center space-x-2 text-sm">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span className="text-slate-300">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Money-Back Guarantee */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-3xl p-8 text-center"
      >
        <Shield className="w-16 h-16 text-blue-400 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-white mb-3">30-Day Money-Back Guarantee</h3>
        <p className="text-slate-300 max-w-2xl mx-auto">
          If MakanGuard doesn't help you save money or prevent theft in the first 30 days, we'll refund 100% of your payment. 
          No questions asked.
        </p>
      </motion.div>

      {/* Pay As You Go */}
      <PayAsYouGoView />

      {/* FAQ */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8">
        <h3 className="text-2xl font-bold text-white mb-6 text-center">Frequently Asked Questions</h3>
        <div className="space-y-4 max-w-3xl mx-auto">
          {[
            {
              q: 'How quickly will my account be activated?',
              a: 'Once you send the payment proof via WhatsApp, your premium account will be activated within 2 hours (usually much faster during business hours).',
            },
            {
              q: 'Can I cancel anytime?',
              a: 'Yes! You can cancel your subscription anytime. No contracts, no commitments. Just WhatsApp us and we\'ll process the cancellation immediately.',
            },
            {
              q: 'Do you offer refunds?',
              a: 'Absolutely. We offer a 30-day money-back guarantee. If you\'re not satisfied for any reason, just let us know and we\'ll refund your full payment.',
            },
            {
              q: 'Is my payment secure?',
              a: 'Yes. We use established Pakistani payment services (NayaPay, JazzCash, Easypaisa) which are all bank-grade secure platforms.',
            },
          ].map((faq, i) => (
            <div key={i} className="p-4 bg-white/5 rounded-xl">
              <h4 className="text-white font-semibold mb-2">{faq.q}</h4>
              <p className="text-sm text-slate-400">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
