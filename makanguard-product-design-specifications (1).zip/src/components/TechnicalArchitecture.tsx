'use client';

import { motion } from 'framer-motion';
import { Server, Database, Smartphone, Cloud, Zap, Lock, Globe, Cpu, HardDrive, Wifi, Code, Layers } from 'lucide-react';

const techStack = {
  frontend: [
    { name: 'React Native', desc: 'Cross-platform mobile', icon: Smartphone, color: 'from-blue-500 to-cyan-500' },
    { name: 'TypeScript', desc: 'Type-safe development', icon: Code, color: 'from-blue-600 to-indigo-600' },
    { name: 'TailwindCSS', desc: 'Utility-first styling', icon: Layers, color: 'from-cyan-500 to-teal-500' },
    { name: 'React Query', desc: 'Data fetching & caching', icon: Zap, color: 'from-purple-500 to-pink-500' },
  ],
  backend: [
    { name: 'Node.js + Express', desc: 'API server', icon: Server, color: 'from-green-500 to-emerald-500' },
    { name: 'PostgreSQL', desc: 'Primary database', icon: Database, color: 'from-blue-500 to-indigo-500' },
    { name: 'Redis', desc: 'Caching layer', icon: Zap, color: 'from-red-500 to-orange-500' },
    { name: 'Socket.io', desc: 'Real-time updates', icon: Wifi, color: 'from-purple-500 to-pink-500' },
  ],
  infrastructure: [
    { name: 'AWS EC2', desc: 'Application hosting', icon: Cloud, color: 'from-orange-500 to-amber-500' },
    { name: 'AWS S3', desc: 'Photo/file storage', icon: HardDrive, color: 'from-blue-500 to-cyan-500' },
    { name: 'CloudFront CDN', desc: 'Content delivery', icon: Globe, color: 'from-purple-500 to-pink-500' },
    { name: 'AWS RDS', desc: 'Managed PostgreSQL', icon: Database, color: 'from-green-500 to-teal-500' },
  ],
  integrations: [
    { name: 'JazzCash API', desc: 'Payment processing', icon: Zap, color: 'from-rose-500 to-pink-500' },
    { name: 'Easypaisa API', desc: 'Payment processing', icon: Zap, color: 'from-green-500 to-emerald-500' },
    { name: 'WhatsApp Business', desc: 'Notifications', icon: Globe, color: 'from-green-600 to-teal-600' },
    { name: 'Google Maps', desc: 'GPS & location', icon: Globe, color: 'from-blue-500 to-indigo-500' },
  ],
};

const dataFlow = [
  {
    layer: 'Client Layer',
    components: ['React Native App', 'Offline Storage (SQLite)', 'Local Photo Cache'],
    color: 'from-blue-500 to-cyan-500',
  },
  {
    layer: 'API Gateway',
    components: ['Load Balancer', 'Rate Limiting', 'Authentication JWT'],
    color: 'from-purple-500 to-pink-500',
  },
  {
    layer: 'Application Layer',
    components: ['Express API', 'Business Logic', 'Background Jobs (Bull)'],
    color: 'from-green-500 to-emerald-500',
  },
  {
    layer: 'Data Layer',
    components: ['PostgreSQL', 'Redis Cache', 'S3 Storage'],
    color: 'from-orange-500 to-red-500',
  },
];

const keyFeatures = [
  {
    title: 'Offline-First Architecture',
    desc: 'App works fully offline. All data syncs when connection returns.',
    icon: Wifi,
    tech: ['SQLite local DB', 'Queue-based sync', 'Conflict resolution'],
  },
  {
    title: 'Real-Time Updates',
    desc: 'Instant notifications and live data updates via WebSockets.',
    icon: Zap,
    tech: ['Socket.io', 'Redis Pub/Sub', 'Push notifications'],
  },
  {
    title: 'Scalable Storage',
    desc: 'Efficient photo/video handling with automatic compression.',
    icon: HardDrive,
    tech: ['S3 storage', 'CloudFront CDN', 'Image optimization'],
  },
  {
    title: 'Multi-Region Support',
    desc: 'Low latency for Pakistan and overseas users.',
    icon: Globe,
    tech: ['Edge locations', 'Regional caching', 'Smart routing'],
  },
];

export default function TechnicalArchitecture() {
  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-orange-500/10 border border-orange-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Cpu className="w-4 h-4 text-orange-400" />
          <span className="text-sm text-orange-400 font-medium">Technical Architecture</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-orange-300 via-red-300 to-pink-300 bg-clip-text text-transparent">
          System Design
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Scalable, secure, and offline-first architecture for MakanGuard
        </p>
      </div>

      {/* Architecture Diagram */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-2xl font-bold text-white mb-8 text-center">System Layers</h2>
        
        <div className="space-y-6">
          {dataFlow.map((layer, index) => (
            <motion.div
              key={layer.layer}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              <div className={`bg-gradient-to-r ${layer.color} p-0.5 rounded-2xl`}>
                <div className="bg-slate-900 rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-white">{layer.layer}</h3>
                    <div className="flex items-center space-x-2">
                      {index < dataFlow.length - 1 && (
                        <motion.div
                          className="flex flex-col items-center"
                          animate={{ y: [0, 5, 0] }}
                          transition={{ duration: 1.5, repeat: Infinity, delay: index * 0.2 }}
                        >
                          <div className="w-0.5 h-8 bg-gradient-to-b from-emerald-500 to-transparent" />
                        </motion.div>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-3 gap-3">
                    {layer.components.map((component, i) => (
                      <div
                        key={i}
                        className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-slate-300 text-center"
                      >
                        {component}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Tech Stack Grid */}
      <div className="grid md:grid-cols-2 gap-8">
        {Object.entries(techStack).map(([category, items], catIndex) => (
          <motion.div
            key={category}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: catIndex * 0.1 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6"
          >
            <h3 className="text-xl font-bold text-white mb-6 capitalize">{category}</h3>
            
            <div className="space-y-3">
              {items.map((tech, i) => (
                <motion.div
                  key={tech.name}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: catIndex * 0.1 + i * 0.05 }}
                  className="flex items-center space-x-3 p-3 bg-white/5 rounded-xl hover:bg-white/10 transition-all group"
                >
                  <div className={`w-10 h-10 bg-gradient-to-br ${tech.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <tech.icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-white font-medium">{tech.name}</div>
                    <div className="text-xs text-slate-400">{tech.desc}</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Key Features */}
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">Architectural Highlights</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          {keyFeatures.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:border-emerald-500/30 transition-all group"
            >
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                
                <div className="flex-1 space-y-3">
                  <h3 className="text-lg font-bold text-white">{feature.title}</h3>
                  <p className="text-sm text-slate-300">{feature.desc}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {feature.tech.map((tech, i) => (
                      <span
                        key={i}
                        className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-xs text-emerald-400"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Database Schema Highlight */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 rounded-3xl p-8 md:p-12"
      >
        <div className="flex items-center justify-center space-x-3 mb-8">
          <Database className="w-8 h-8 text-indigo-400" />
          <h2 className="text-3xl font-bold text-white">Database Schema</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              table: 'projects',
              desc: 'Core project data',
              fields: ['id', 'plot_size', 'floors', 'city', 'budget'],
            },
            {
              table: 'deliveries',
              desc: 'Material deliveries',
              fields: ['material_type', 'quantity', 'photos', 'gps_location'],
            },
            {
              table: 'usage_logs',
              desc: 'Daily usage tracking',
              fields: ['material_type', 'quantity', 'work_desc', 'voice_note'],
            },
            {
              table: 'alerts',
              desc: 'Discrepancy alerts',
              fields: ['alert_type', 'severity', 'suggested_action'],
            },
            {
              table: 'progress_photos',
              desc: 'Construction progress',
              fields: ['photo_url', 'caption', 'gps_location', 'date'],
            },
            {
              table: 'material_estimates',
              desc: 'Estimated quantities',
              fields: ['material', 'estimated_qty', 'current_price'],
            },
          ].map((schema, i) => (
            <motion.div
              key={schema.table}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-4 space-y-3"
            >
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-indigo-500 rounded-full" />
                <h4 className="text-white font-mono font-semibold">{schema.table}</h4>
              </div>
              <p className="text-xs text-slate-400">{schema.desc}</p>
              <div className="space-y-1">
                {schema.fields.map((field, j) => (
                  <div key={j} className="text-xs text-slate-500 font-mono pl-4">
                    • {field}
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Performance Metrics */}
      <div className="grid md:grid-cols-4 gap-6">
        {[
          { label: 'API Response', value: '<100ms', icon: Zap },
          { label: 'Offline Support', value: '100%', icon: Wifi },
          { label: 'Photo Upload', value: '<3s', icon: Cloud },
          { label: 'Uptime SLA', value: '99.9%', icon: Server },
        ].map((metric, i) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:bg-white/10 transition-all"
          >
            <metric.icon className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
            <div className="text-3xl font-bold text-white mb-2">{metric.value}</div>
            <div className="text-sm text-slate-400">{metric.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
