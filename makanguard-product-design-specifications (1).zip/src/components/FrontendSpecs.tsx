'use client';

import { motion } from 'framer-motion';
import { Palette, Type, Layout, Smartphone, Globe, Zap, Eye, Heart } from 'lucide-react';

const colorPalette = {
  primary: [
    { name: 'Emerald 500', hex: '#10b981', usage: 'Primary actions, success states' },
    { name: 'Teal 500', hex: '#14b8a6', usage: 'Secondary accents, links' },
    { name: 'Slate 950', hex: '#020617', usage: 'Background, dark surfaces' },
  ],
  semantic: [
    { name: 'Rose 500', hex: '#f43f5e', usage: 'Alerts, critical warnings' },
    { name: 'Amber 500', hex: '#f59e0b', usage: 'Warnings, caution states' },
    { name: 'Blue 500', hex: '#3b82f6', usage: 'Information, links' },
    { name: 'Purple 500', hex: '#a855f7', usage: 'Premium features' },
  ],
  neutral: [
    { name: 'Slate 100', hex: '#f1f5f9', usage: 'Light text, borders' },
    { name: 'Slate 400', hex: '#94a3b8', usage: 'Placeholder text' },
    { name: 'Slate 700', hex: '#334155', usage: 'Secondary text' },
  ],
};

const typography = [
  { name: 'Display', font: 'Inter', weight: '700', size: '48-72px', usage: 'Hero titles' },
  { name: 'Heading 1', font: 'Inter', weight: '700', size: '36-48px', usage: 'Page titles' },
  { name: 'Heading 2', font: 'Inter', weight: '600', size: '24-32px', usage: 'Section headers' },
  { name: 'Body', font: 'Inter', weight: '400', size: '16px', usage: 'Main content' },
  { name: 'Caption', font: 'Inter', weight: '500', size: '12-14px', usage: 'Labels, metadata' },
  { name: 'Urdu Text', font: 'Noto Nastaliq Urdu', weight: '400-700', size: '16-24px', usage: 'Urdu content' },
];

const components = [
  {
    name: 'Buttons',
    variants: ['Primary (Gradient)', 'Secondary (Outline)', 'Ghost (Transparent)', 'Icon-only'],
    states: ['Default', 'Hover', 'Active', 'Disabled', 'Loading'],
    specs: 'Rounded-xl (12px), Min height 44px (touch target), Gradient from emerald to teal',
  },
  {
    name: 'Input Fields',
    variants: ['Text', 'Number', 'Select', 'Voice Input', 'Photo Upload'],
    states: ['Empty', 'Focused', 'Filled', 'Error', 'Disabled'],
    specs: 'Rounded-xl (12px), Border white/20, Focus ring emerald-500, Dark bg with white/10',
  },
  {
    name: 'Cards',
    variants: ['Info Card', 'Progress Card', 'Alert Card', 'Action Card'],
    states: ['Default', 'Hover', 'Selected', 'Disabled'],
    specs: 'Rounded-2xl (16px), Backdrop blur, Border white/10, Padding 16-24px',
  },
  {
    name: 'Modals',
    variants: ['Confirmation', 'Form', 'Photo Viewer', 'Alert'],
    states: ['Open', 'Closing', 'Loading'],
    specs: 'Centered, Max-width 90vw, Backdrop blur + dark overlay, Slide up animation',
  },
];

const animations = [
  {
    name: 'Page Transitions',
    type: 'Fade + Slide',
    duration: '300-400ms',
    easing: 'ease-out',
    desc: 'Smooth page transitions with opacity and subtle Y movement',
  },
  {
    name: 'Button Interactions',
    type: 'Scale + Shadow',
    duration: '150ms',
    easing: 'ease-in-out',
    desc: 'Hover scale 1.02, active scale 0.98, with shadow expansion',
  },
  {
    name: 'Loading States',
    type: 'Pulse + Shimmer',
    duration: '1.5s',
    easing: 'linear',
    desc: 'Skeleton screens with shimmer effect for async data',
  },
  {
    name: 'Success Feedback',
    type: 'Checkmark + Scale',
    duration: '500ms',
    easing: 'spring',
    desc: 'Animated checkmark with satisfying spring bounce',
  },
];

const responsiveBreakpoints = [
  { size: 'Mobile', width: '320-640px', cols: '1', desc: 'Single column, full-width cards' },
  { size: 'Tablet', width: '640-1024px', cols: '2', desc: 'Two columns, side-by-side layout' },
  { size: 'Desktop', width: '1024px+', cols: '3-4', desc: 'Multi-column grids, max-width 1280px' },
];

const designPrinciples = [
  {
    title: 'Calm & Reassuring',
    desc: 'Use gentle animations, warm colors, and respectful language. Never alarming.',
    icon: Heart,
    color: 'from-rose-500 to-pink-500',
  },
  {
    title: 'Instant Feedback',
    desc: 'Every action has immediate visual feedback. No uncertainty.',
    icon: Zap,
    color: 'from-yellow-500 to-orange-500',
  },
  {
    title: 'Cultural Respect',
    desc: 'Bilingual (Urdu/English), culturally appropriate imagery, respectful tone.',
    icon: Globe,
    color: 'from-green-500 to-emerald-500',
  },
  {
    title: 'Accessible',
    desc: 'High contrast, large touch targets, voice input, works for elderly parents.',
    icon: Eye,
    color: 'from-blue-500 to-indigo-500',
  },
];

export default function FrontendSpecs() {
  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Palette className="w-4 h-4 text-indigo-400" />
          <span className="text-sm text-indigo-400 font-medium">Frontend Specification</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-indigo-300 via-purple-300 to-pink-300 bg-clip-text text-transparent">
          Design System
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Complete visual language and component specifications for MakanGuard
        </p>
      </div>

      {/* Design Principles */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {designPrinciples.map((principle, i) => (
          <motion.div
            key={principle.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all group"
          >
            <div className={`w-12 h-12 bg-gradient-to-br ${principle.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <principle.icon className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">{principle.title}</h3>
            <p className="text-sm text-slate-400">{principle.desc}</p>
          </motion.div>
        ))}
      </div>

      {/* Color Palette */}
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">Color Palette</h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          {Object.entries(colorPalette).map(([category, colors]) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6"
            >
              <h3 className="text-lg font-bold text-white mb-4 capitalize">{category} Colors</h3>
              
              <div className="space-y-3">
                {colors.map((color) => (
                  <div key={color.name} className="space-y-2">
                    <div className="flex items-center space-x-3">
                      <div
                        className="w-12 h-12 rounded-xl shadow-lg flex-shrink-0"
                        style={{ backgroundColor: color.hex }}
                      />
                      <div className="flex-1">
                        <div className="text-white font-medium text-sm">{color.name}</div>
                        <div className="text-slate-400 text-xs font-mono">{color.hex}</div>
                      </div>
                    </div>
                    <div className="text-xs text-slate-500 pl-15">{color.usage}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Typography */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Typography</h2>
        
        <div className="space-y-4">
          {typography.map((type, i) => (
            <motion.div
              key={type.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="grid md:grid-cols-5 gap-4 items-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-all"
            >
              <div className="md:col-span-1">
                <div className="text-white font-semibold">{type.name}</div>
              </div>
              <div className="md:col-span-1">
                <div className="text-sm text-slate-400">
                  {type.font}
                </div>
              </div>
              <div className="md:col-span-1">
                <div className="text-sm text-slate-400">
                  {type.weight} • {type.size}
                </div>
              </div>
              <div className="md:col-span-2">
                <div className="text-xs text-slate-500">{type.usage}</div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 p-6 bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl">
          <h4 className="text-white font-semibold mb-3">Font Loading Strategy</h4>
          <ul className="space-y-2 text-sm text-slate-300">
            <li className="flex items-start space-x-2">
              <span className="text-purple-400">•</span>
              <span>Google Fonts API for Inter (Latin) with font-display: swap</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-purple-400">•</span>
              <span>Self-hosted Noto Nastaliq Urdu for better performance in Pakistan</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-purple-400">•</span>
              <span>Subset fonts to include only required characters for faster load</span>
            </li>
          </ul>
        </div>
      </motion.div>

      {/* Components */}
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">Component Library</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          {components.map((component, index) => (
            <motion.div
              key={component.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
            >
              <h3 className="text-xl font-bold text-white mb-4">{component.name}</h3>
              
              <div className="space-y-3">
                <div>
                  <div className="text-xs text-slate-400 mb-2">Variants</div>
                  <div className="flex flex-wrap gap-2">
                    {component.variants.map((variant) => (
                      <span
                        key={variant}
                        className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-xs text-emerald-400"
                      >
                        {variant}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-xs text-slate-400 mb-2">States</div>
                  <div className="flex flex-wrap gap-2">
                    {component.states.map((state) => (
                      <span
                        key={state}
                        className="px-2 py-1 bg-blue-500/10 border border-blue-500/20 rounded-lg text-xs text-blue-400"
                      >
                        {state}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10">
                  <div className="text-xs text-slate-400 mb-1">Specifications</div>
                  <p className="text-sm text-slate-300">{component.specs}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Animations */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Motion Design</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          {animations.map((anim, i) => (
            <motion.div
              key={anim.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-6"
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="text-lg font-bold text-white">{anim.name}</h4>
                <span className="px-2 py-1 bg-orange-500/20 border border-orange-500/30 rounded-lg text-xs text-orange-400 font-mono">
                  {anim.duration}
                </span>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Type:</span>
                  <span className="text-white">{anim.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Easing:</span>
                  <span className="text-white font-mono text-xs">{anim.easing}</span>
                </div>
              </div>
              
              <p className="text-xs text-slate-400 mt-3">{anim.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 p-6 bg-white/5 rounded-2xl">
          <h4 className="text-white font-semibold mb-3">Animation Principles</h4>
          <ul className="space-y-2 text-sm text-slate-300">
            <li className="flex items-start space-x-2">
              <span className="text-orange-400">•</span>
              <span>Always respect prefers-reduced-motion for accessibility</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-orange-400">•</span>
              <span>Keep animations under 400ms for responsiveness feel</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-orange-400">•</span>
              <span>Use spring physics for natural, satisfying interactions</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className="text-orange-400">•</span>
              <span>Stagger list animations by 50-100ms per item</span>
            </li>
          </ul>
        </div>
      </motion.div>

      {/* Responsive Design */}
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">Responsive Breakpoints</h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          {responsiveBreakpoints.map((bp, i) => (
            <motion.div
              key={bp.size}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:bg-white/10 transition-all"
            >
              <Smartphone className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-white mb-2">{bp.size}</h3>
              <div className="text-sm text-emerald-400 font-mono mb-3">{bp.width}</div>
              <div className="text-xs text-slate-400 mb-2">{bp.cols} column layout</div>
              <p className="text-xs text-slate-500">{bp.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Accessibility */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12"
      >
        <div className="flex items-center justify-center space-x-3 mb-8">
          <Eye className="w-8 h-8 text-blue-400" />
          <h2 className="text-3xl font-bold text-white">Accessibility Standards</h2>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {[
            { title: 'Color Contrast', value: 'WCAG AAA', desc: 'Minimum 7:1 ratio for text' },
            { title: 'Touch Targets', value: '44x44px', desc: 'Minimum size for all interactive elements' },
            { title: 'Font Sizes', value: '16px+', desc: 'Readable without zoom, scales to 200%' },
            { title: 'Screen Readers', value: 'Full Support', desc: 'Semantic HTML, ARIA labels' },
            { title: 'Keyboard Nav', value: 'Complete', desc: 'All features accessible via keyboard' },
            { title: 'Voice Input', value: 'Urdu + English', desc: 'Voice-to-text for elderly users' },
          ].map((standard, i) => (
            <motion.div
              key={standard.title}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="p-4 bg-white/5 rounded-xl"
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-white font-semibold">{standard.title}</h4>
                <span className="px-2 py-1 bg-blue-500/20 border border-blue-500/30 rounded-lg text-xs text-blue-400">
                  {standard.value}
                </span>
              </div>
              <p className="text-xs text-slate-400">{standard.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
