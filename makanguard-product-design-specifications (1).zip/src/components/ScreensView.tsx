'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { Home, Package, Camera, TrendingDown, Bell, Settings, ChevronRight, MapPin, Phone, Upload, CheckCircle2, AlertTriangle } from 'lucide-react';

type ScreenType = 'onboarding' | 'dashboard' | 'estimate' | 'delivery' | 'pricing' | 'alerts';

const screens = [
  { id: 'onboarding' as ScreenType, label: 'Onboarding', icon: Home, color: 'from-blue-500 to-cyan-500' },
  { id: 'dashboard' as ScreenType, label: 'Dashboard', icon: Home, color: 'from-green-500 to-emerald-500' },
  { id: 'estimate' as ScreenType, label: 'Estimator', icon: Package, color: 'from-purple-500 to-pink-500' },
  { id: 'delivery' as ScreenType, label: 'Delivery Log', icon: Camera, color: 'from-orange-500 to-red-500' },
  { id: 'pricing' as ScreenType, label: 'Price Tracker', icon: TrendingDown, color: 'from-indigo-500 to-purple-500' },
  { id: 'alerts' as ScreenType, label: 'Alerts', icon: Bell, color: 'from-rose-500 to-pink-500' },
];

export default function ScreensView() {
  const [activeScreen, setActiveScreen] = useState<ScreenType>('dashboard');

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Home className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400 font-medium">Interactive Screens</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-green-300 via-emerald-300 to-teal-300 bg-clip-text text-transparent">
          App Screens
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Interactive mockups showcasing key user interfaces
        </p>
      </div>

      {/* Screen Selector */}
      <div className="flex flex-wrap justify-center gap-3">
        {screens.map((screen) => (
          <motion.button
            key={screen.id}
            onClick={() => setActiveScreen(screen.id)}
            className={`px-4 py-2 rounded-xl border transition-all ${
              activeScreen === screen.id
                ? 'bg-white/10 border-white/20 shadow-lg'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="flex items-center space-x-2">
              <screen.icon className="w-4 h-4 text-emerald-400" />
              <span className="text-sm font-medium text-white">{screen.label}</span>
            </div>
          </motion.button>
        ))}
      </div>

      {/* Phone Mockup Container */}
      <div className="flex justify-center">
        <motion.div
          className="relative w-full max-w-sm"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Phone Frame */}
          <div className="relative bg-slate-900 rounded-[3rem] p-3 shadow-2xl shadow-emerald-500/20 border-4 border-slate-800">
            {/* Notch */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-20" />
            
            {/* Screen Content */}
            <div className="bg-slate-950 rounded-[2.5rem] overflow-hidden h-[600px] relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeScreen}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="h-full overflow-y-auto"
                >
                  {activeScreen === 'dashboard' && <DashboardScreen />}
                  {activeScreen === 'onboarding' && <OnboardingScreen />}
                  {activeScreen === 'estimate' && <EstimateScreen />}
                  {activeScreen === 'delivery' && <DeliveryScreen />}
                  {activeScreen === 'pricing' && <PricingScreen />}
                  {activeScreen === 'alerts' && <AlertsScreen />}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* Decorative Elements */}
          <motion.div
            className="absolute -top-10 -right-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
          />
          <motion.div
            className="absolute -bottom-10 -left-10 w-40 h-40 bg-teal-500/10 rounded-full blur-3xl"
            animate={{ scale: [1.2, 1, 1.2] }}
            transition={{ duration: 5, repeat: Infinity }}
          />
        </motion.div>
      </div>
    </div>
  );
}

// Dashboard Screen
function DashboardScreen() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2 text-emerald-400 text-sm mb-1">
            <MapPin className="w-4 h-4" />
            <span>Lahore, Pakistan</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Assalam-o-Alaikum</h1>
          <p className="text-sm text-slate-400">Ahmed's Dream House</p>
        </div>
        <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-full flex items-center justify-center">
          <Home className="w-6 h-6 text-white" />
        </div>
      </div>

      {/* Progress Card */}
      <motion.div
        className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-2xl p-4"
        whileHover={{ scale: 1.02 }}
      >
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-emerald-400 font-medium">Overall Progress</span>
          <span className="text-2xl font-bold text-white">42%</span>
        </div>
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
            initial={{ width: 0 }}
            animate={{ width: '42%' }}
            transition={{ duration: 1, delay: 0.2 }}
          />
        </div>
        <div className="grid grid-cols-3 gap-2 mt-3 text-xs">
          <div className="text-center">
            <div className="text-white font-bold">23</div>
            <div className="text-slate-400">Days</div>
          </div>
          <div className="text-center">
            <div className="text-white font-bold">₨4.2L</div>
            <div className="text-slate-400">Spent</div>
          </div>
          <div className="text-center">
            <div className="text-white font-bold">₨5.8L</div>
            <div className="text-slate-400">Budget</div>
          </div>
        </div>
      </motion.div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { icon: Package, label: 'Log Delivery', color: 'from-blue-500 to-cyan-500' },
          { icon: Camera, label: 'Add Photos', color: 'from-purple-500 to-pink-500' },
          { icon: TrendingDown, label: 'Check Prices', color: 'from-orange-500 to-red-500' },
          { icon: Bell, label: 'View Alerts', color: 'from-rose-500 to-pink-500' },
        ].map((action, i) => (
          <motion.button
            key={action.label}
            className={`bg-gradient-to-br ${action.color} p-4 rounded-xl text-white text-left`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <action.icon className="w-6 h-6 mb-2" />
            <div className="text-sm font-medium">{action.label}</div>
          </motion.button>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-400">Recent Activity</h3>
        {[
          { icon: Package, text: '50 cement bags delivered', time: '2 hours ago' },
          { icon: Camera, text: 'Progress photos uploaded', time: '5 hours ago' },
          { icon: CheckCircle2, text: 'Foundation milestone completed', time: '1 day ago' },
        ].map((item, i) => (
          <motion.div
            key={i}
            className="flex items-center space-x-3 p-3 bg-white/5 rounded-xl"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
              <item.icon className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="flex-1">
              <div className="text-sm text-white">{item.text}</div>
              <div className="text-xs text-slate-500">{item.time}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Onboarding Screen
function OnboardingScreen() {
  return (
    <div className="p-6 space-y-6 flex flex-col justify-center h-full">
      <div className="text-center space-y-4">
        <motion.div
          className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-3xl flex items-center justify-center mx-auto"
          animate={{ rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Home className="w-10 h-10 text-white" />
        </motion.div>
        
        <h2 className="text-2xl font-bold text-white">Apna Ghar Banaye</h2>
        <p className="text-slate-400">Let's setup your dream house project</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-sm text-slate-400 mb-2 block">Plot Size</label>
          <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
            <option>5 Marla</option>
            <option>10 Marla</option>
            <option>1 Kanal</option>
          </select>
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">Number of Floors</label>
          <div className="grid grid-cols-3 gap-2">
            {[1, 2, 3].map((num) => (
              <button
                key={num}
                className="py-3 bg-white/10 border border-white/20 rounded-xl text-white hover:bg-emerald-500/20 hover:border-emerald-500/50 transition-all"
              >
                {num}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">House Type</label>
          <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
            <option>Standard</option>
            <option>Premium</option>
            <option>Luxury</option>
          </select>
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">City</label>
          <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
            <option>Lahore</option>
            <option>Karachi</option>
            <option>Islamabad</option>
          </select>
        </div>
      </div>

      <motion.button
        className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Calculate Estimate
      </motion.button>
    </div>
  );
}

// Estimate Screen
function EstimateScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-1">Material Estimate</h2>
        <p className="text-sm text-slate-400">10 Marla • Double Story • Lahore</p>
      </div>

      <motion.div
        className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-2xl p-6 text-center"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <div className="text-4xl font-bold text-white mb-2">₨ 52.4 Lakh</div>
        <div className="text-sm text-emerald-400">Estimated Total Cost</div>
      </motion.div>

      <div className="space-y-3">
        {[
          { name: 'Cement Bags', qty: '1,850', unit: 'bags', price: '₨ 8.5L', icon: Package },
          { name: 'Steel Bars', qty: '12.5', unit: 'tons', price: '₨ 18.2L', icon: Package },
          { name: 'Bricks', qty: '85,000', unit: 'pcs', price: '₨ 12.8L', icon: Package },
          { name: 'Sand', qty: '420', unit: 'cft', price: '₨ 6.2L', icon: Package },
        ].map((item, i) => (
          <motion.div
            key={item.name}
            className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                <item.icon className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="text-white font-medium">{item.name}</div>
                <div className="text-xs text-slate-400">{item.qty} {item.unit}</div>
              </div>
            </div>
            <div className="text-emerald-400 font-semibold">{item.price}</div>
          </motion.div>
        ))}
      </div>

      <button className="w-full py-3 bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all">
        Download Detailed Report
      </button>
    </div>
  );
}

// Delivery Screen
function DeliveryScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Log Delivery</h2>
        <div className="text-xs text-emerald-400">Offline Mode</div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-sm text-slate-400 mb-2 block">Material Type</label>
          <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
            <option>Cement Bags</option>
            <option>Steel Bars</option>
            <option>Bricks</option>
          </select>
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">Quantity</label>
          <input
            type="number"
            placeholder="Enter quantity"
            className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white placeholder-slate-500"
          />
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">Photos</label>
          <div className="grid grid-cols-2 gap-3">
            <button className="aspect-square bg-white/10 border-2 border-dashed border-white/20 rounded-xl flex flex-col items-center justify-center hover:bg-white/20 transition-all">
              <Camera className="w-8 h-8 text-slate-400 mb-2" />
              <span className="text-xs text-slate-400">Stack Photo</span>
            </button>
            <button className="aspect-square bg-white/10 border-2 border-dashed border-white/20 rounded-xl flex flex-col items-center justify-center hover:bg-white/20 transition-all">
              <Upload className="w-8 h-8 text-slate-400 mb-2" />
              <span className="text-xs text-slate-400">Invoice</span>
            </button>
          </div>
        </div>

        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex items-start space-x-2">
          <MapPin className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-sm text-emerald-400 font-medium">GPS Location Added</div>
            <div className="text-xs text-slate-400">31.5204° N, 74.3587° E</div>
          </div>
        </div>
      </div>

      <motion.button
        className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Save Delivery
      </motion.button>
    </div>
  );
}

// Pricing Screen
function PricingScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Live Prices</h2>
        <div className="text-xs text-emerald-400">Updated 2h ago</div>
      </div>

      <div className="space-y-3">
        {[
          { name: 'Lucky Cement', price: 'Rs 1,450', change: '-2.3%', trend: 'down' },
          { name: 'Bestway Cement', price: 'Rs 1,420', change: '-1.8%', trend: 'down' },
          { name: 'DG Cement', price: 'Rs 1,480', change: '+0.5%', trend: 'up' },
          { name: 'Amreli Steel', price: 'Rs 285,000/ton', change: '-3.2%', trend: 'down' },
        ].map((item, i) => (
          <motion.div
            key={item.name}
            className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div>
              <div className="text-white font-medium">{item.name}</div>
              <div className="text-xs text-slate-400">{item.price}</div>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
              item.trend === 'down' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
            }`}>
              {item.change}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/30 rounded-2xl p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Bell className="w-5 h-5 text-blue-400" />
          <span className="text-sm font-semibold text-blue-400">Price Alerts</span>
        </div>
        <p className="text-xs text-slate-300 mb-3">Get notified when prices drop below your target</p>
        <button className="w-full py-2 bg-blue-500/20 border border-blue-500/30 rounded-lg text-blue-400 text-sm font-medium hover:bg-blue-500/30 transition-all">
          Set Alert
        </button>
      </div>
    </div>
  );
}

// Alerts Screen
function AlertsScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Notifications</h2>
        <div className="w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
      </div>

      <div className="space-y-3">
        {[
          {
            type: 'warning',
            icon: AlertTriangle,
            title: 'Material Discrepancy Detected',
            desc: '15 cement bags variance between delivery and usage',
            action: 'Review Details',
            color: 'from-orange-500 to-red-500',
          },
          {
            type: 'success',
            icon: TrendingDown,
            title: 'Price Drop Alert',
            desc: 'Lucky Cement price dropped by 2.3% today',
            action: 'View Prices',
            color: 'from-green-500 to-emerald-500',
          },
          {
            type: 'info',
            icon: Camera,
            title: 'Daily Photos Uploaded',
            desc: 'Contractor uploaded 5 progress photos',
            action: 'View Gallery',
            color: 'from-blue-500 to-cyan-500',
          },
        ].map((alert, i) => (
          <motion.div
            key={i}
            className="bg-white/5 rounded-xl p-4 space-y-3"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="flex items-start space-x-3">
              <div className={`w-10 h-10 bg-gradient-to-br ${alert.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                <alert.icon className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="text-white font-medium mb-1">{alert.title}</div>
                <div className="text-xs text-slate-400">{alert.desc}</div>
              </div>
            </div>
            <button className={`w-full py-2 bg-gradient-to-r ${alert.color} rounded-lg text-white text-sm font-medium`}>
              {alert.action}
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
