'use client';

import { motion } from 'framer-motion';
import { Zap, Brain, MessageSquare, Eye, TrendingUp, Cpu, FileText, Sparkles, DollarSign, CheckCircle2, AlertTriangle } from 'lucide-react';

const payAsYouGoOptions = [
  {
    id: 'chatbot-pack',
    icon: MessageSquare,
    name: '20 Chatbot Messages',
    price: 200,
    description: 'Get expert construction advice in Urdu/English',
    color: 'from-blue-500 to-cyan-500',
    popular: false,
  },
  {
    id: 'estimate-single',
    icon: Brain,
    name: 'Single AI Estimate',
    price: 500,
    description: 'AI-powered material quantity calculation for one plan',
    color: 'from-purple-500 to-pink-500',
    popular: true,
  },
  {
    id: 'photo-analysis',
    icon: Eye,
    name: 'Photo Analysis',
    price: 300,
    description: 'AI verification of construction progress from photos',
    color: 'from-green-500 to-emerald-500',
    popular: false,
  },
  {
    id: 'document-review',
    icon: FileText,
    name: 'Document Review',
    price: 400,
    description: 'AI analysis of contract or invoice',
    color: 'from-orange-500 to-red-500',
    popular: false,
  },
  {
    id: 'voice-pack',
    icon: Sparkles,
    name: '50 Voice Commands',
    price: 200,
    description: 'Hands-free Urdu voice assistant',
    color: 'from-teal-500 to-cyan-500',
    popular: false,
  },
];

export default function PayAsYouGoView() {
  return (
    <div className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 rounded-3xl p-8 md:p-12 mt-8">
      <div className="text-center mb-8">
        <div className="inline-flex items-center space-x-2 px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full mb-4">
          <Zap className="w-4 h-4 text-indigo-400" />
          <span className="text-sm text-indigo-400 font-medium">Pay As You Go</span>
        </div>
        <h2 className="text-3xl font-bold text-white mb-3">Don't Need Monthly Subscription?</h2>
        <p className="text-slate-300 max-w-2xl mx-auto">
          Purchase individual AI features as needed. Perfect if you only need occasional AI assistance.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {payAsYouGoOptions.map((option, index) => (
          <motion.div
            key={option.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all group ${
              option.popular ? 'ring-2 ring-emerald-500/50' : ''
            }`}
          >
            {option.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <div className="px-3 py-1 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full text-xs font-semibold text-white">
                  POPULAR
                </div>
              </div>
            )}

            <div className={`w-14 h-14 bg-gradient-to-br ${option.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <option.icon className="w-7 h-7 text-white" />
            </div>

            <h3 className="text-xl font-bold text-white mb-2">{option.name}</h3>
            <p className="text-sm text-slate-400 mb-4">{option.description}</p>

            <div className="flex items-baseline space-x-1 mb-4">
              <span className="text-3xl font-bold text-white">Rs. {option.price}</span>
              <span className="text-slate-400">one-time</span>
            </div>

            <motion.button
              className={`w-full py-3 bg-gradient-to-r ${option.color} rounded-xl text-white font-semibold`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Purchase Now
            </motion.button>
          </motion.div>
        ))}
      </div>

      <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-6">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
          <div className="flex-1">
            <h4 className="text-lg font-semibold text-amber-400 mb-2">Save More with Premium</h4>
            <p className="text-sm text-slate-300 mb-3">
              If you use AI features regularly, Premium subscription is much more cost-effective:
            </p>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div className="bg-white/5 rounded-lg p-3">
                <div className="text-slate-400 mb-1">Pay-As-You-Go Cost:</div>
                <div className="text-white font-bold">Rs. 2,000-3,000/month</div>
                <div className="text-xs text-slate-500">(for regular usage)</div>
              </div>
              <div className="bg-emerald-500/20 border border-emerald-500/30 rounded-lg p-3">
                <div className="text-emerald-400 mb-1">Premium Subscription:</div>
                <div className="text-white font-bold">Rs. 5,999/month</div>
                <div className="text-xs text-emerald-400">Unlimited everything!</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 text-center">
        <p className="text-sm text-slate-400">
          💡 <strong>Smart Tip:</strong> Premium subscribers save an average of Rs. 50,000+ on their projects through AI theft detection
        </p>
      </div>
    </div>
  );
}
