'use client';

import { motion } from 'framer-motion';
import { DollarSign, TrendingUp, Users, Zap, Store, FileText, Award, Shield, Percent, Package, Phone, CreditCard } from 'lucide-react';

const revenueStreams = [
  {
    id: 'subscriptions',
    title: 'Premium Subscriptions',
    description: 'Recurring monthly revenue from homeowners and contractors',
    icon: CreditCard,
    color: 'from-emerald-500 to-teal-500',
    pricing: 'Rs. 5,999/month per user',
    projections: [
      { users: 1000, monthly: 5999000, annual: 71988000 },
      { users: 5000, monthly: 29995000, annual: 359940000 },
      { users: 10000, monthly: 59990000, annual: 719880000 },
    ],
    conversionRate: '15%',
    churnRate: '5%',
    ltv: 'Rs. 144,000',
  },
  {
    id: 'supplier-marketplace',
    title: 'Supplier Marketplace Commission',
    description: 'Earn 3-5% commission on every material order placed through the app',
    icon: Store,
    color: 'from-blue-500 to-indigo-500',
    pricing: '3-5% per transaction',
    projections: [
      { orders: 500, avgOrder: 50000, commission: 0.04, monthly: 1000000, annual: 12000000 },
      { orders: 2000, avgOrder: 50000, commission: 0.04, monthly: 4000000, annual: 48000000 },
      { orders: 5000, avgOrder: 50000, commission: 0.04, monthly: 10000000, annual: 120000000 },
    ],
    details: [
      'One-tap cement ordering',
      'Steel supplier network',
      'Bulk material delivery',
      'Price comparison tools',
      'Verified supplier badges',
      'Review & rating system',
    ],
  },
  {
    id: 'contractor-verification',
    title: 'Contractor Background Checks',
    description: 'Homeowners pay Rs. 2,999 to verify contractor credentials and history',
    icon: Shield,
    color: 'from-purple-500 to-pink-500',
    pricing: 'Rs. 2,999 per verification',
    projections: [
      { checks: 200, price: 2999, monthly: 599800, annual: 7197600 },
      { checks: 800, price: 2999, monthly: 2399200, annual: 28790400 },
      { checks: 1500, price: 2999, monthly: 4498500, annual: 53982000 },
    ],
    details: [
      'CNIC verification',
      'Previous project history',
      'Client testimonials',
      'Police verification',
      'Credit score check',
      'Dispute history',
    ],
  },
  {
    id: 'document-services',
    title: 'Legal Document Templates',
    description: 'Sell contractor agreements, payment schedules, and legal templates',
    icon: FileText,
    color: 'from-orange-500 to-red-500',
    pricing: 'Rs. 1,499 - Rs. 4,999 per template',
    projections: [
      { sales: 150, avgPrice: 2999, monthly: 449850, annual: 5398200 },
      { sales: 500, avgPrice: 2999, monthly: 1499500, annual: 17994000 },
      { sales: 1000, avgPrice: 2999, monthly: 2999000, annual: 35988000 },
    ],
    details: [
      'Contractor agreement templates',
      'Payment milestone schedules',
      'Material delivery checklists',
      'Warranty documents',
      'Dispute resolution forms',
      'Project completion certificates',
    ],
  },
  {
    id: 'insurance-partnership',
    title: 'Construction Insurance Referrals',
    description: 'Partner with insurance companies for construction coverage referrals',
    icon: Award,
    color: 'from-teal-500 to-cyan-500',
    pricing: 'Rs. 5,000 per policy sold',
    projections: [
      { policies: 50, commission: 5000, monthly: 250000, annual: 3000000 },
      { policies: 200, commission: 5000, monthly: 1000000, annual: 12000000 },
      { policies: 500, commission: 5000, monthly: 2500000, annual: 30000000 },
    ],
    details: [
      'Material theft insurance',
      'Fire & damage coverage',
      'Worker injury protection',
      'Project delay insurance',
      'Natural disaster coverage',
      'Equipment protection',
    ],
  },
  {
    id: 'white-label',
    title: 'White Label for Developers',
    description: 'Sell white-labeled version to real estate developers and housing societies',
    icon: Package,
    color: 'from-amber-500 to-yellow-500',
    pricing: 'Rs. 99,999/month per developer',
    projections: [
      { clients: 2, price: 99999, monthly: 199998, annual: 2399976 },
      { clients: 5, price: 99999, monthly: 499995, annual: 5999940 },
      { clients: 10, price: 99999, monthly: 999990, annual: 11999880 },
    ],
    details: [
      'Custom branding & logo',
      'Dedicated instance',
      'Multi-project management',
      'Custom reports',
      'API access',
      'Priority support',
    ],
  },
  {
    id: 'training',
    title: 'Construction Training Courses',
    description: 'Online courses teaching homeowners how to manage construction projects',
    icon: Users,
    color: 'from-rose-500 to-pink-500',
    pricing: 'Rs. 9,999 per course',
    projections: [
      { students: 100, price: 9999, monthly: 999900, annual: 11998800 },
      { students: 300, price: 9999, monthly: 2999700, annual: 35996400 },
      { students: 500, price: 9999, monthly: 4999500, annual: 59994000 },
    ],
    details: [
      'Home construction basics',
      'Material quality identification',
      'Contractor management',
      'Budget planning',
      'Timeline scheduling',
      'Quality control checks',
    ],
  },
  {
    id: 'consultation',
    title: 'Expert Consultation Services',
    description: '1-on-1 video calls with civil engineers and construction experts',
    icon: Phone,
    color: 'from-indigo-500 to-purple-500',
    pricing: 'Rs. 4,999 per hour',
    projections: [
      { calls: 50, price: 4999, monthly: 249950, annual: 2999400 },
      { calls: 150, price: 4999, monthly: 749850, annual: 8998200 },
      { calls: 300, price: 4999, monthly: 1499700, annual: 17996400 },
    ],
    details: [
      'Project plan review',
      'Material selection advice',
      'Cost optimization',
      'Quality inspection',
      'Dispute resolution',
      'Technical problem-solving',
    ],
  },
  {
    id: 'bulk-discounts',
    title: 'Bulk Purchase Discounts Program',
    description: 'Negotiate group discounts with suppliers, keep 1-2% margin',
    icon: Percent,
    color: 'from-green-500 to-emerald-500',
    pricing: '1-2% margin on bulk orders',
    projections: [
      { volume: 5000000, margin: 0.015, monthly: 75000, annual: 900000 },
      { volume: 20000000, margin: 0.015, monthly: 300000, annual: 3600000 },
      { volume: 50000000, margin: 0.015, monthly: 750000, annual: 9000000 },
    ],
    details: [
      'Cement bulk orders',
      'Steel wholesale pricing',
      'Brick factory direct',
      'Sand & gravel deals',
      'Paint discounts',
      'Tiles & fixtures',
    ],
  },
];

const totalRevenue = {
  conservative: {
    subscriptions: 5999000,
    marketplace: 1000000,
    verification: 599800,
    documents: 449850,
    insurance: 250000,
    whiteLabel: 199998,
    training: 999900,
    consultation: 249950,
    bulk: 75000,
  },
  moderate: {
    subscriptions: 29995000,
    marketplace: 4000000,
    verification: 2399200,
    documents: 1499500,
    insurance: 1000000,
    whiteLabel: 499995,
    training: 2999700,
    consultation: 749850,
    bulk: 300000,
  },
  aggressive: {
    subscriptions: 59990000,
    marketplace: 10000000,
    verification: 4498500,
    documents: 2999000,
    insurance: 2500000,
    whiteLabel: 999990,
    training: 4999500,
    consultation: 1499700,
    bulk: 750000,
  },
};

export default function RevenueView() {
  const conservative = Object.values(totalRevenue.conservative).reduce((a, b) => a + b, 0);
  const moderate = Object.values(totalRevenue.moderate).reduce((a, b) => a + b, 0);
  const aggressive = Object.values(totalRevenue.aggressive).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <DollarSign className="w-4 h-4 text-green-400" />
          <span className="text-sm text-green-400 font-medium">Revenue Streams & Monetization</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-green-300 via-emerald-300 to-teal-300 bg-clip-text text-transparent">
          9 Revenue Streams
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Multiple income sources beyond subscriptions to build a highly profitable business
        </p>
      </div>

      {/* Revenue Projections */}
      <div className="grid md:grid-cols-3 gap-6">
        {[
          { 
            label: 'Conservative', 
            monthly: conservative, 
            annual: conservative * 12, 
            color: 'from-blue-500 to-cyan-500',
            desc: 'Year 1 baseline',
          },
          { 
            label: 'Moderate', 
            monthly: moderate, 
            annual: moderate * 12, 
            color: 'from-purple-500 to-pink-500',
            desc: 'Year 2 growth',
          },
          { 
            label: 'Aggressive', 
            monthly: aggressive, 
            annual: aggressive * 12, 
            color: 'from-orange-500 to-red-500',
            desc: 'Year 3 scale',
          },
        ].map((scenario, i) => (
          <motion.div
            key={scenario.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`bg-gradient-to-br ${scenario.color} bg-opacity-10 backdrop-blur-xl border border-white/10 rounded-3xl p-6`}
          >
            <div className="text-center space-y-3">
              <div className="text-sm font-medium text-slate-400">{scenario.label} Scenario</div>
              <div className="text-4xl font-bold text-white">
                Rs. {(scenario.monthly / 1000000).toFixed(1)}M
              </div>
              <div className="text-sm text-emerald-400">per month</div>
              <div className="pt-3 border-t border-white/10">
                <div className="text-2xl font-bold text-white">
                  Rs. {(scenario.annual / 1000000).toFixed(1)}M
                </div>
                <div className="text-xs text-slate-400">annual revenue</div>
              </div>
              <div className="text-xs text-slate-500">{scenario.desc}</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Revenue Streams */}
      <div className="space-y-6">
        {revenueStreams.map((stream, index) => (
          <motion.div
            key={stream.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 md:p-8 hover:bg-white/10 transition-all group"
          >
            <div className="flex items-start space-x-4 mb-6">
              <div className={`w-14 h-14 bg-gradient-to-br ${stream.color} rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                <stream.icon className="w-7 h-7 text-white" />
              </div>
              
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-2xl font-bold text-white">{stream.title}</h3>
                  <div className="text-right">
                    <div className="text-sm text-slate-400 mb-1">Pricing</div>
                    <div className="text-lg font-semibold text-emerald-400">{stream.pricing}</div>
                  </div>
                </div>
                <p className="text-slate-300 mb-6">{stream.description}</p>

                {/* Revenue Projections */}
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  {stream.projections.map((proj, i) => (
                    <div key={i} className="bg-white/5 border border-white/10 rounded-xl p-4">
                      <div className="text-xs text-slate-400 mb-2">
                        {i === 0 ? 'Conservative' : i === 1 ? 'Moderate' : 'Aggressive'}
                      </div>
                      <div className="text-xl font-bold text-white mb-1">
                        Rs. {(proj.monthly / 1000).toFixed(0)}K
                      </div>
                      <div className="text-xs text-slate-500">monthly</div>
                      <div className="text-sm text-emerald-400 mt-1">
                        Rs. {(proj.annual / 1000000).toFixed(2)}M annual
                      </div>
                    </div>
                  ))}
                </div>

                {/* Details */}
                {stream.details && (
                  <div>
                    <h4 className="text-sm font-semibold text-slate-400 mb-3">Features Included:</h4>
                    <div className="grid md:grid-cols-2 gap-2">
                      {stream.details.map((detail, i) => (
                        <div key={i} className="flex items-center space-x-2 text-sm text-slate-300">
                          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Additional Metrics */}
                {stream.conversionRate && (
                  <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-white/10">
                    <div>
                      <div className="text-xs text-slate-400">Conversion Rate</div>
                      <div className="text-lg font-semibold text-emerald-400">{stream.conversionRate}</div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">Monthly Churn</div>
                      <div className="text-lg font-semibold text-amber-400">{stream.churnRate}</div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">Lifetime Value</div>
                      <div className="text-lg font-semibold text-purple-400">{stream.ltv}</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Revenue Summary</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-emerald-400">Key Advantages</h3>
            <div className="space-y-3">
              {[
                'Multiple revenue streams = lower risk',
                'Recurring subscription base = predictable income',
                'Commission-based models = no upfront cost',
                'High-margin digital products',
                'Scalable without linear costs',
                'Network effects strengthen over time',
              ].map((item, i) => (
                <div key={i} className="flex items-start space-x-2 text-sm text-slate-300">
                  <TrendingUp className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-emerald-400">Growth Multipliers</h3>
            <div className="space-y-3">
              {[
                'AI features = zero marginal cost',
                'Free LM Arena models = no AI expenses',
                'Marketplace scales with users',
                'Digital products = 95%+ profit margin',
                'Word-of-mouth referrals',
                'Cross-selling between products',
              ].map((item, i) => (
                <div key={i} className="flex items-start space-x-2 text-sm text-slate-300">
                  <Zap className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 p-6 bg-white/10 rounded-2xl text-center">
          <div className="text-4xl font-bold text-white mb-2">
            Rs. {((moderate * 12) / 1000000).toFixed(1)}M
          </div>
          <div className="text-sm text-emerald-400 mb-4">
            Projected Year 2 Annual Revenue (Moderate Scenario)
          </div>
          <div className="text-xs text-slate-400">
            With 5,000 active users and moderate adoption across all revenue streams
          </div>
        </div>
      </motion.div>
    </div>
  );
}
