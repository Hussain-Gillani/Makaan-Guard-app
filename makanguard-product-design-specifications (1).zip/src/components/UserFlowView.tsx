'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { Home, ArrowRight, CheckCircle2, Camera, Bell, Shield, Globe, Package, TrendingDown } from 'lucide-react';

type UserPersona = 'homeowner' | 'overseas' | 'contractor';

const personas = [
  {
    id: 'homeowner' as UserPersona,
    title: 'Local Homeowner',
    description: 'Building dream house in Pakistan',
    icon: Home,
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'overseas' as UserPersona,
    title: 'Overseas Pakistani',
    description: 'Building remotely from abroad',
    icon: Globe,
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: 'contractor' as UserPersona,
    title: 'Contractor',
    description: 'Managing construction work',
    icon: Package,
    color: 'from-orange-500 to-red-500',
  },
];

const flows = {
  homeowner: [
    {
      step: 1,
      title: 'Download & Setup',
      description: 'Install app, answer 7-8 questions about plot size, floors, house type',
      duration: '5 min',
      icon: Home,
      details: ['Choose plot size (marla/kanal)', 'Select number of floors', 'Pick house type', 'Enter city location'],
    },
    {
      step: 2,
      title: 'Get Instant Estimate',
      description: 'View animated house and exact material quantities with current prices',
      duration: '2 min',
      icon: CheckCircle2,
      details: ['See cement bags needed', 'View steel quantity', 'Check brick count', 'Review total budget'],
    },
    {
      step: 3,
      title: 'Monitor Prices',
      description: 'Receive daily price updates and alerts for drops',
      duration: 'Daily',
      icon: TrendingDown,
      details: ['Track cement prices', 'Monitor steel rates', 'Get price-drop alerts', 'Compare suppliers'],
    },
    {
      step: 4,
      title: 'Log Deliveries',
      description: 'Photo + quantity + invoice for each material delivery',
      duration: '30 sec',
      icon: Camera,
      details: ['Take stack photo', 'Enter quantity', 'Photo invoice', 'Auto GPS tag'],
    },
    {
      step: 5,
      title: 'Receive Alerts',
      description: 'Get calm notifications about discrepancies or issues',
      duration: 'As needed',
      icon: Bell,
      details: ['Material variance alerts', 'Suggested actions', 'Progress updates', 'Price opportunities'],
    },
    {
      step: 6,
      title: 'Track Progress',
      description: 'View daily photos and weekly collages of construction',
      duration: 'Daily',
      icon: Shield,
      details: ['Daily photo journal', 'Weekly collages', 'Milestone tracking', 'Video updates'],
    },
  ],
  overseas: [
    {
      step: 1,
      title: 'Remote Setup',
      description: 'Setup project from abroad with English-first interface',
      duration: '10 min',
      icon: Globe,
      details: ['Answer setup questions', 'Enter family contact', 'Set notification preferences', 'Choose currency display'],
    },
    {
      step: 2,
      title: 'Assign Local Helper',
      description: 'Add family member or supervisor as on-ground manager',
      duration: '3 min',
      icon: Home,
      details: ['Invite via WhatsApp', 'Set permissions', 'Share project access', 'Enable notifications'],
    },
    {
      step: 3,
      title: 'Daily Dashboard',
      description: 'View comprehensive overview every morning (your timezone)',
      duration: '5 min',
      icon: CheckCircle2,
      details: ['Yesterday\'s progress', 'Photo updates', 'Material status', 'Budget tracking'],
    },
    {
      step: 4,
      title: 'Video Check-ins',
      description: 'One-tap video call to site supervisor',
      duration: '10 min',
      icon: Camera,
      details: ['Schedule calls', 'Live site walk', 'Ask questions', 'Record sessions'],
    },
    {
      step: 5,
      title: 'Alert Response',
      description: 'Receive and respond to issues remotely',
      duration: 'As needed',
      icon: Bell,
      details: ['WhatsApp alerts', 'Review evidence', 'Take action', 'Communicate fixes'],
    },
    {
      step: 6,
      title: 'Milestone Payments',
      description: 'Release payments after photo + material verification',
      duration: '2 min',
      icon: Shield,
      details: ['Review milestone', 'Verify photos', 'Check materials', 'Release via JazzCash'],
    },
  ],
  contractor: [
    {
      step: 1,
      title: 'Join Project',
      description: 'Receive invitation from homeowner via WhatsApp',
      duration: '2 min',
      icon: Package,
      details: ['Accept invitation', 'Review project scope', 'See expectations', 'Confirm role'],
    },
    {
      step: 2,
      title: 'Log Daily Usage',
      description: 'Quick voice input in Urdu for materials used today',
      duration: '2 min',
      icon: Camera,
      details: ['Voice input supported', 'Select material', 'Enter quantity', 'Add work notes'],
    },
    {
      step: 3,
      title: 'Upload Progress Photos',
      description: 'Take 4-5 photos daily with brief captions',
      duration: '3 min',
      icon: Camera,
      details: ['Photo current work', 'Add voice caption', 'Auto GPS tag', 'Submit to owner'],
    },
    {
      step: 4,
      title: 'Respectful Interface',
      description: 'Experience designed to feel respectful, not accusatory',
      duration: 'Always',
      icon: Shield,
      details: ['Urdu language support', 'Simple workflows', 'No judgmental tone', 'Professional respect'],
    },
    {
      step: 5,
      title: 'Communication',
      description: 'Direct communication with homeowner when needed',
      duration: 'As needed',
      icon: Bell,
      details: ['Request materials', 'Report delays', 'Share updates', 'Answer questions'],
    },
    {
      step: 6,
      title: 'Milestone Completion',
      description: 'Mark milestones complete with photo proof',
      duration: '5 min',
      icon: CheckCircle2,
      details: ['Upload completion photos', 'Document materials used', 'Request payment', 'Get owner approval'],
    },
  ],
};

export default function UserFlowView() {
  const [selectedPersona, setSelectedPersona] = useState<UserPersona>('homeowner');

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ArrowRight className="w-4 h-4 text-purple-400" />
          <span className="text-sm text-purple-400 font-medium">User Flows</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-300 via-pink-300 to-rose-300 bg-clip-text text-transparent">
          Journey Mapping
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Complete user journeys for homeowners, overseas Pakistanis, and contractors
        </p>
      </div>

      {/* Persona Selector */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {personas.map((persona) => (
          <motion.button
            key={persona.id}
            onClick={() => setSelectedPersona(persona.id)}
            className={`relative p-6 rounded-2xl border transition-all ${
              selectedPersona === persona.id
                ? 'bg-white/10 border-white/20 shadow-xl'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <div className={`w-12 h-12 bg-gradient-to-br ${persona.color} rounded-xl flex items-center justify-center mb-4 mx-auto`}>
              <persona.icon className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">{persona.title}</h3>
            <p className="text-sm text-slate-400">{persona.description}</p>
            
            {selectedPersona === persona.id && (
              <motion.div
                layoutId="activePersona"
                className="absolute inset-0 border-2 border-emerald-500 rounded-2xl"
                initial={false}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
            )}
          </motion.button>
        ))}
      </div>

      {/* Flow Steps */}
      <motion.div
        key={selectedPersona}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="relative">
          {/* Connection Line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-teal-500 to-cyan-500 hidden md:block" />

          {/* Steps */}
          <div className="space-y-6">
            {flows[selectedPersona].map((step, index) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative"
              >
                {/* Step Number Badge */}
                <div className="absolute left-0 top-6 w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/50 z-10 hidden md:flex">
                  <span className="text-2xl font-bold text-white">{step.step}</span>
                </div>

                {/* Step Content */}
                <div className="md:ml-24 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all group">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="md:hidden w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
                        <span className="text-lg font-bold text-white">{step.step}</span>
                      </div>
                      <step.icon className="w-8 h-8 text-emerald-400" />
                      <div>
                        <h3 className="text-xl font-bold text-white group-hover:text-emerald-400 transition-colors">
                          {step.title}
                        </h3>
                        <p className="text-sm text-slate-400">{step.description}</p>
                      </div>
                    </div>
                    <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-xs font-medium text-emerald-400">
                      {step.duration}
                    </div>
                  </div>

                  {/* Details Grid */}
                  <div className="grid md:grid-cols-2 gap-2 mt-4">
                    {step.details.map((detail, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: index * 0.1 + i * 0.05 }}
                        className="flex items-center space-x-2 text-sm text-slate-400"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                        <span>{detail}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Summary Stats */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-3xl p-8"
      >
        <h3 className="text-2xl font-bold text-white mb-6 text-center">Journey Highlights</h3>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center space-y-2">
            <div className="text-4xl font-bold text-emerald-400">
              {selectedPersona === 'homeowner' ? '30 sec' : selectedPersona === 'overseas' ? '5 min' : '2 min'}
            </div>
            <div className="text-sm text-slate-400">Average Task Time</div>
          </div>
          
          <div className="text-center space-y-2">
            <div className="text-4xl font-bold text-teal-400">
              {flows[selectedPersona].length}
            </div>
            <div className="text-sm text-slate-400">Key Steps</div>
          </div>
          
          <div className="text-center space-y-2">
            <div className="text-4xl font-bold text-cyan-400">
              {selectedPersona === 'homeowner' ? 'Daily' : selectedPersona === 'overseas' ? 'Weekly' : 'Daily'}
            </div>
            <div className="text-sm text-slate-400">Engagement</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
