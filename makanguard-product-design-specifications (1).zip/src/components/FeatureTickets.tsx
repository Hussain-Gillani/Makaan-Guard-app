'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { CheckCircle2, Circle, Clock, AlertCircle, Package, TrendingDown, Camera, Shield, Globe, Crown } from 'lucide-react';

type Priority = 'critical' | 'high' | 'medium' | 'low';
type Status = 'planned' | 'in_progress' | 'completed';

interface Ticket {
  id: string;
  scope: number;
  title: string;
  description: string;
  priority: Priority;
  status: Status;
  estimatedDays: number;
  dependencies?: string[];
  acceptanceCriteria: string[];
}

const tickets: Ticket[] = [
  // Scope 1 Tickets
  {
    id: 'S1-T1',
    scope: 1,
    title: 'Setup Wizard UI',
    description: 'Build 7-8 step guided setup flow with plot size, floors, house type selection',
    priority: 'critical',
    status: 'completed',
    estimatedDays: 5,
    acceptanceCriteria: [
      'Responsive wizard with progress indicator',
      'Marla/Kanal selector with visual reference',
      'Floor count selector (1-3)',
      'House type dropdown (Standard/Premium/Luxury)',
      'City dropdown with major Pakistani cities',
      'Animated house illustration that grows with selections',
      'Data validation on each step',
      'Mobile-first design with smooth transitions',
    ],
  },
  {
    id: 'S1-T2',
    scope: 1,
    title: 'Material Estimation Engine',
    description: 'Backend logic to calculate exact cement, steel, brick quantities based on inputs',
    priority: 'critical',
    status: 'completed',
    estimatedDays: 8,
    acceptanceCriteria: [
      'Formula-based calculation for cement bags per marla/floor',
      'Steel quantity calculation in tons',
      'Brick count estimation',
      'Sand/gravel cubic feet calculation',
      'House type multipliers (Standard 1x, Premium 1.2x, Luxury 1.5x)',
      'Store estimates in PostgreSQL',
      'API endpoint returning full material breakdown',
      'Unit tests for calculation accuracy',
    ],
  },
  {
    id: 'S1-T3',
    scope: 1,
    title: 'Live Price Integration',
    description: 'Fetch and display current market rates for materials in selected city',
    priority: 'high',
    status: 'completed',
    estimatedDays: 6,
    dependencies: ['S1-T2'],
    acceptanceCriteria: [
      'Price data table for cement brands (Lucky, Bestway, DG)',
      'Steel rates (Amreli, Mughal per ton)',
      'City-specific pricing (Lahore, Karachi, Islamabad)',
      'Manual price update admin panel',
      'Display last updated timestamp',
      'Calculate total estimated budget',
      'Format currency in PKR with commas',
    ],
  },

  // Scope 2 Tickets
  {
    id: 'S2-T1',
    scope: 2,
    title: 'Price Tracker Dashboard',
    description: 'Daily updated material prices with trend indicators',
    priority: 'high',
    status: 'in_progress',
    estimatedDays: 5,
    acceptanceCriteria: [
      'Table view of materials with current prices',
      'Up/down trend arrows with percentage change',
      'Color coding (green for drops, red for increases)',
      'Filter by material type',
      'Historical price chart (7-day view)',
      'Pull-to-refresh functionality',
      'Last updated timestamp',
    ],
  },
  {
    id: 'S2-T2',
    scope: 2,
    title: 'Price Alert System',
    description: 'User-configurable alerts for price drops',
    priority: 'high',
    status: 'planned',
    estimatedDays: 7,
    dependencies: ['S2-T1'],
    acceptanceCriteria: [
      'Alert creation UI: select material, set target price',
      'Daily background job checking prices vs alerts',
      'Push notification when price drops below target',
      'WhatsApp notification option',
      'Alert management (edit, delete, pause)',
      'Alert history log',
      '"Good news!" tone in notifications',
    ],
  },
  {
    id: 'S2-T3',
    scope: 2,
    title: 'Price Data Scraping',
    description: 'Automated daily scraping of material prices from reliable sources',
    priority: 'medium',
    status: 'planned',
    estimatedDays: 10,
    acceptanceCriteria: [
      'Scraper for major supplier websites',
      'Scheduled daily cron job (6 AM Pakistan time)',
      'Data validation and outlier detection',
      'Fallback to manual entry if scraping fails',
      'Store historical prices in database',
      'Admin dashboard to review scraped data',
    ],
  },

  // Scope 3 Tickets
  {
    id: 'S3-T1',
    scope: 3,
    title: 'Delivery Logging Flow',
    description: 'Photo-first delivery recording with quantity and GPS',
    priority: 'critical',
    status: 'in_progress',
    estimatedDays: 8,
    acceptanceCriteria: [
      'Material selector dropdown',
      'Quantity input with number keypad',
      'Camera integration for stack photo',
      'Camera integration for invoice photo',
      'Voice input support (Urdu)',
      'Auto-capture GPS coordinates',
      'Auto-add current date/time',
      'Offline support with queue-based sync',
      'Under 30 seconds to complete',
      'Green confirmation message in Urdu',
    ],
  },
  {
    id: 'S3-T2',
    scope: 3,
    title: 'Photo Upload & Storage',
    description: 'S3 integration for photo storage with compression',
    priority: 'high',
    status: 'planned',
    estimatedDays: 5,
    dependencies: ['S3-T1'],
    acceptanceCriteria: [
      'Client-side image compression (max 2MB)',
      'Upload to AWS S3 with unique naming',
      'CloudFront CDN for fast retrieval',
      'Thumbnail generation',
      'Watermark with date/time/GPS',
      'Handle offline uploads with retry logic',
      'Progress indicator during upload',
    ],
  },
  {
    id: 'S3-T3',
    scope: 3,
    title: 'Delivery History View',
    description: 'Timeline view of all deliveries with photos and details',
    priority: 'medium',
    status: 'planned',
    estimatedDays: 4,
    dependencies: ['S3-T1'],
    acceptanceCriteria: [
      'Chronological list of deliveries',
      'Group by material type or date',
      'Photo gallery view',
      'Summary totals per material',
      'Export to PDF report',
      'Search and filter options',
    ],
  },

  // Scope 4 Tickets
  {
    id: 'S4-T1',
    scope: 4,
    title: 'Daily Usage Logging',
    description: 'Contractor interface to log daily material usage',
    priority: 'critical',
    status: 'planned',
    estimatedDays: 6,
    acceptanceCriteria: [
      'Simple form: material, quantity, work description',
      'Voice input support in Urdu',
      'Quick-select common materials',
      'Work description with voice note option',
      'Respectful, non-accusatory UI tone',
      'Offline support',
      'Completion in under 2 minutes',
    ],
  },
  {
    id: 'S4-T2',
    scope: 4,
    title: 'Anti-Theft Engine',
    description: 'Background job comparing deliveries vs usage vs estimates',
    priority: 'critical',
    status: 'planned',
    estimatedDays: 10,
    dependencies: ['S3-T1', 'S4-T1'],
    acceptanceCriteria: [
      'Daily calculation: total delivered - total used',
      'Compare against estimated usage for work done',
      'Threshold-based alerts (>10% variance)',
      'Severity levels (minor, moderate, critical)',
      'Only notify owner (private alerts)',
      'Include evidence: photos, quantities, dates',
      'Suggest respectful next actions',
      'No direct accusation in language',
    ],
  },
  {
    id: 'S4-T3',
    scope: 4,
    title: 'Discrepancy Alert System',
    description: 'Calm notification system for material variances',
    priority: 'high',
    status: 'planned',
    estimatedDays: 5,
    dependencies: ['S4-T2'],
    acceptanceCriteria: [
      'Push notification to owner only',
      'Clear explanation of discrepancy',
      'Visual comparison (chart/numbers)',
      'Suggested actions (verify, ask contractor, check photos)',
      'Mark as resolved functionality',
      'Alert history and trends',
      'Tone: "Here\'s what we noticed" not "Alert! Theft!"',
    ],
  },

  // Scope 5 Tickets
  {
    id: 'S5-T1',
    scope: 5,
    title: 'Daily Photo Journal',
    description: 'Contractor uploads 4-5 daily progress photos with captions',
    priority: 'high',
    status: 'planned',
    estimatedDays: 6,
    acceptanceCriteria: [
      'Multi-photo upload (4-5 at once)',
      'Voice or text caption per photo',
      'Auto GPS tagging',
      'Auto date/time stamping',
      'Photo gallery organized by date',
      'Daily digest view',
      'Simple contractor interface',
    ],
  },
  {
    id: 'S5-T2',
    scope: 5,
    title: 'Weekly Collage Generator',
    description: 'Automated weekly photo collage creation',
    priority: 'medium',
    status: 'planned',
    estimatedDays: 7,
    dependencies: ['S5-T1'],
    acceptanceCriteria: [
      'Select 10-15 best photos from week',
      'Arrange in attractive grid layout',
      'Add week label, date range',
      'Include key stats (materials used, work done)',
      'Generate as shareable image',
      'Send via WhatsApp to overseas owner',
      'Warm, family-album aesthetic',
    ],
  },
  {
    id: 'S5-T3',
    scope: 5,
    title: 'Overseas Dashboard',
    description: 'English-first dashboard for diaspora users',
    priority: 'high',
    status: 'planned',
    estimatedDays: 8,
    dependencies: ['S5-T1', 'S5-T2'],
    acceptanceCriteria: [
      'Timezone-aware daily digest (morning delivery)',
      'One-tap video call to supervisor',
      'Weekly collage prominent display',
      'Budget tracking in USD/GBP/EUR/PKR',
      'Progress percentage with milestone markers',
      'Last 24 hours activity summary',
      'Simplified, clear language (no jargon)',
    ],
  },

  // Scope 6 Tickets
  {
    id: 'S6-T1',
    scope: 6,
    title: 'Subscription System',
    description: 'Freemium model with premium tier at $15-25/month',
    priority: 'high',
    status: 'planned',
    estimatedDays: 10,
    acceptanceCriteria: [
      'Free tier: basic tracking, limited alerts',
      'Premium tier: full anti-theft, milestones, payments',
      'Subscription management UI',
      'Payment via JazzCash/Easypaisa/Stripe',
      'Overseas users billed in USD via Stripe',
      'Trial period (14 days)',
      'Cancel anytime, no contracts',
      'Email reminders before renewal',
    ],
  },
  {
    id: 'S6-T2',
    scope: 6,
    title: 'Milestone Verification',
    description: 'Photo proof + material verification for milestone completion',
    priority: 'critical',
    status: 'planned',
    estimatedDays: 9,
    dependencies: ['S6-T1'],
    acceptanceCriteria: [
      'Define milestones (foundation, roof, etc.)',
      'Contractor submits completion with photos',
      'System verifies materials match estimate',
      'Owner reviews and approves',
      'Checklist of completion criteria',
      'Reject with feedback option',
      'Notification to contractor on approval',
    ],
  },
  {
    id: 'S6-T3',
    scope: 6,
    title: 'Payment Integration',
    description: 'JazzCash/Easypaisa integration for milestone payments',
    priority: 'critical',
    status: 'planned',
    estimatedDays: 12,
    dependencies: ['S6-T2'],
    acceptanceCriteria: [
      'JazzCash Merchant API integration',
      'Easypaisa Merchant API integration',
      'Payment amount tied to milestone',
      'Require MFA for payment release',
      'Payment history and receipts',
      'Contractor receives SMS on payment',
      'Escrow-like: only release after approval',
      'Transaction fees clearly shown',
    ],
  },
  {
    id: 'S6-T4',
    scope: 6,
    title: 'Supplier Network',
    description: 'One-tap ordering from trusted suppliers with pre-filled quantities',
    priority: 'medium',
    status: 'planned',
    estimatedDays: 15,
    dependencies: ['S1-T2'],
    acceptanceCriteria: [
      'Curated list of verified suppliers per city',
      'Pre-fill order quantities from estimate',
      'WhatsApp-based order flow',
      'Delivery scheduling',
      'Supplier ratings and reviews',
      'Compare prices across suppliers',
      'Order history tracking',
    ],
  },
];

const scopeIcons = [Package, TrendingDown, Camera, Shield, Globe, Crown];
const scopeColors = [
  'from-blue-500 to-cyan-500',
  'from-green-500 to-emerald-500',
  'from-purple-500 to-pink-500',
  'from-orange-500 to-red-500',
  'from-indigo-500 to-purple-500',
  'from-teal-500 to-cyan-500',
];

const priorityConfig = {
  critical: { color: 'from-red-500 to-rose-500', label: 'Critical', textColor: 'text-red-400' },
  high: { color: 'from-orange-500 to-amber-500', label: 'High', textColor: 'text-orange-400' },
  medium: { color: 'from-yellow-500 to-orange-500', label: 'Medium', textColor: 'text-yellow-400' },
  low: { color: 'from-blue-500 to-cyan-500', label: 'Low', textColor: 'text-blue-400' },
};

const statusConfig = {
  completed: { icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10', label: 'Completed' },
  in_progress: { icon: Clock, color: 'text-blue-400', bg: 'bg-blue-500/10', label: 'In Progress' },
  planned: { icon: Circle, color: 'text-slate-400', bg: 'bg-slate-500/10', label: 'Planned' },
};

export default function FeatureTickets() {
  const [selectedScope, setSelectedScope] = useState<number | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<Status | null>(null);

  const filteredTickets = tickets.filter((ticket) => {
    if (selectedScope && ticket.scope !== selectedScope) return false;
    if (selectedStatus && ticket.status !== selectedStatus) return false;
    return true;
  });

  const stats = {
    total: tickets.length,
    completed: tickets.filter((t) => t.status === 'completed').length,
    inProgress: tickets.filter((t) => t.status === 'in_progress').length,
    planned: tickets.filter((t) => t.status === 'planned').length,
  };

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-teal-500/10 border border-teal-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <CheckCircle2 className="w-4 h-4 text-teal-400" />
          <span className="text-sm text-teal-400 font-medium">Feature Development Roadmap</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-teal-300 via-cyan-300 to-blue-300 bg-clip-text text-transparent">
          Feature Tickets
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Complete breakdown of development tasks across all 6 scopes
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {[
          { label: 'Total Tickets', value: stats.total, icon: Package, color: 'from-blue-500 to-cyan-500' },
          { label: 'Completed', value: stats.completed, icon: CheckCircle2, color: 'from-green-500 to-emerald-500' },
          { label: 'In Progress', value: stats.inProgress, icon: Clock, color: 'from-orange-500 to-amber-500' },
          { label: 'Planned', value: stats.planned, icon: Circle, color: 'from-purple-500 to-pink-500' },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
          >
            <stat.icon className="w-8 h-8 text-teal-400 mb-3" />
            <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
            <div className="text-sm text-slate-400">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px]">
          <label className="text-sm text-slate-400 mb-2 block">Filter by Scope</label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedScope(null)}
              className={`px-4 py-2 rounded-xl border transition-all ${
                selectedScope === null
                  ? 'bg-white/10 border-white/20'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
            >
              <span className="text-sm text-white">All</span>
            </button>
            {[1, 2, 3, 4, 5, 6].map((scope) => {
              const Icon = scopeIcons[scope - 1];
              return (
                <button
                  key={scope}
                  onClick={() => setSelectedScope(scope)}
                  className={`px-4 py-2 rounded-xl border transition-all ${
                    selectedScope === scope
                      ? 'bg-white/10 border-white/20'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Icon className="w-4 h-4 text-teal-400" />
                    <span className="text-sm text-white">Scope {scope}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex-1 min-w-[200px]">
          <label className="text-sm text-slate-400 mb-2 block">Filter by Status</label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedStatus(null)}
              className={`px-4 py-2 rounded-xl border transition-all ${
                selectedStatus === null
                  ? 'bg-white/10 border-white/20'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
            >
              <span className="text-sm text-white">All</span>
            </button>
            {Object.entries(statusConfig).map(([status, config]) => (
              <button
                key={status}
                onClick={() => setSelectedStatus(status as Status)}
                className={`px-4 py-2 rounded-xl border transition-all ${
                  selectedStatus === status
                    ? 'bg-white/10 border-white/20'
                    : 'bg-white/5 border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <config.icon className={`w-4 h-4 ${config.color}`} />
                  <span className="text-sm text-white">{config.label}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tickets List */}
      <div className="space-y-6">
        {filteredTickets.map((ticket, index) => {
          const Icon = scopeIcons[ticket.scope - 1];
          const statusCfg = statusConfig[ticket.status];
          const priorityCfg = priorityConfig[ticket.priority];
          
          return (
            <motion.div
              key={ticket.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 md:p-8 hover:bg-white/10 transition-all group"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${scopeColors[ticket.scope - 1]} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="px-2 py-1 bg-teal-500/10 border border-teal-500/20 rounded-lg text-xs font-medium text-teal-400">
                        {ticket.id}
                      </span>
                      <span className="px-2 py-1 bg-white/10 rounded-lg text-xs text-slate-400">
                        Scope {ticket.scope}
                      </span>
                      <span className={`px-2 py-1 ${statusCfg.bg} rounded-lg text-xs ${statusCfg.color} font-medium flex items-center space-x-1`}>
                        <statusCfg.icon className="w-3 h-3" />
                        <span>{statusCfg.label}</span>
                      </span>
                      <span className={`px-2 py-1 bg-gradient-to-r ${priorityCfg.color} text-white rounded-lg text-xs font-semibold`}>
                        {priorityCfg.label}
                      </span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-white mb-2">{ticket.title}</h3>
                    <p className="text-sm text-slate-300 mb-4">{ticket.description}</p>

                    {ticket.dependencies && (
                      <div className="flex items-center space-x-2 mb-3">
                        <AlertCircle className="w-4 h-4 text-amber-400" />
                        <span className="text-xs text-amber-400">
                          Depends on: {ticket.dependencies.join(', ')}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center space-x-4 text-sm text-slate-400">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4" />
                        <span>{ticket.estimatedDays} days</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{ticket.acceptanceCriteria.length} acceptance criteria</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Acceptance Criteria */}
              <div className="border-t border-white/10 pt-4">
                <h4 className="text-sm font-semibold text-slate-400 mb-3">Acceptance Criteria</h4>
                <div className="grid md:grid-cols-2 gap-2">
                  {ticket.acceptanceCriteria.map((criteria, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.05 + i * 0.02 }}
                      className="flex items-start space-x-2 text-sm text-slate-300"
                    >
                      <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1.5 ${
                        ticket.status === 'completed' ? 'bg-emerald-500' : 'bg-slate-500'
                      }`} />
                      <span>{criteria}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Summary */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-teal-500/10 to-cyan-500/10 border border-teal-500/20 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Development Timeline</h2>
        
        <div className="grid md:grid-cols-6 gap-6">
          {[1, 2, 3, 4, 5, 6].map((scope) => {
            const scopeTickets = tickets.filter((t) => t.scope === scope);
            const totalDays = scopeTickets.reduce((sum, t) => sum + t.estimatedDays, 0);
            const Icon = scopeIcons[scope - 1];
            
            return (
              <div key={scope} className="text-center">
                <div className={`w-16 h-16 bg-gradient-to-br ${scopeColors[scope - 1]} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{totalDays}d</div>
                <div className="text-xs text-slate-400">Scope {scope}</div>
                <div className="text-xs text-slate-500 mt-1">{scopeTickets.length} tickets</div>
              </div>
            );
          })}
        </div>

        <div className="mt-8 text-center">
          <div className="text-4xl font-bold text-teal-400 mb-2">
            {tickets.reduce((sum, t) => sum + t.estimatedDays, 0)} days
          </div>
          <div className="text-sm text-slate-400">Total Estimated Development Time</div>
          <div className="text-xs text-slate-500 mt-1">
            ~{Math.ceil(tickets.reduce((sum, t) => sum + t.estimatedDays, 0) / 30)} months with parallel development
          </div>
        </div>
      </motion.div>
    </div>
  );
}
