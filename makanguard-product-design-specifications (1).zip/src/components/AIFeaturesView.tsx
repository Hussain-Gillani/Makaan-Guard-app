'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { Bot, Camera, TrendingUp, Shield, Zap, DollarSign, CheckCircle2, Sparkles, Brain, Eye, AlertTriangle, MessageSquare, Cpu, Lock } from 'lucide-react';

const aiFeatures = [
  {
    id: 'ai-estimator',
    title: 'AI-Powered Material Estimator',
    description: 'Upload your floor plan and get instant AI-generated material quantities using computer vision and machine learning',
    icon: Brain,
    color: 'from-purple-500 to-pink-500',
    pricing: { free: '2 estimates only', premium: 'Unlimited estimates' },
    revenue: 'Rs. 2,500/month or Rs. 500/estimate',
    features: [
      'Advanced AI plan analysis',
      'Auto-detect rooms and dimensions',
      'Precise material quantity predictions',
      'Real-time cost estimation',
      'Export detailed PDF reports',
      'Compare multiple plans',
    ],
    technology: 'Advanced AI Models',
    accuracy: '98%',
  },
  {
    id: 'ai-chatbot',
    title: 'Urdu/English Construction Advisor',
    description: '24/7 AI chatbot answering construction questions, material advice, and troubleshooting in Urdu and English',
    icon: MessageSquare,
    color: 'from-blue-500 to-cyan-500',
    pricing: { free: '20 messages only', premium: 'Unlimited + Priority responses' },
    revenue: 'Rs. 1,800/month or Rs. 200 per 20 messages',
    features: [
      'Bilingual support (Urdu/English)',
      'Expert construction advice',
      'Material recommendations',
      'Problem troubleshooting',
      'Contractor guidance',
      'Building code compliance',
    ],
    technology: 'Enterprise AI Assistant',
    accuracy: '95%',
  },
  {
    id: 'fraud-detection',
    title: 'AI Theft Detection Engine',
    description: 'Machine learning algorithm detecting material discrepancies, unusual patterns, and potential fraud automatically',
    icon: Shield,
    color: 'from-red-500 to-orange-500',
    pricing: { free: 'Not available in free tier', premium: 'Full protection enabled' },
    revenue: 'Rs. 3,500/month - Premium Only',
    features: [
      'AI pattern recognition for theft',
      'Real-time anomaly detection',
      'Predictive fraud alerts',
      'Historical pattern analysis',
      'Risk scoring per contractor',
      'Automatic evidence compilation',
    ],
    technology: 'Enterprise Machine Learning',
    accuracy: '92%',
  },
  {
    id: 'photo-analysis',
    title: 'AI Construction Progress Analyzer',
    description: 'Computer vision analyzing progress photos to verify work completion, quality, and milestone achievement',
    icon: Eye,
    color: 'from-green-500 to-emerald-500',
    pricing: { free: '5 photo analyses only', premium: 'Unlimited AI analysis' },
    revenue: 'Rs. 2,800/month or Rs. 300/analysis',
    features: [
      'AI construction progress tracking',
      'Quality verification scoring',
      'Milestone completion checks',
      'Material verification from photos',
      'Automated defect detection',
      'Before/after comparisons',
    ],
    technology: 'Advanced Computer Vision AI',
    accuracy: '94%',
  },
  {
    id: 'price-predictor',
    title: 'AI Price Prediction & Optimizer',
    description: 'Machine learning predicting material price movements and recommending optimal purchase timing',
    icon: TrendingUp,
    color: 'from-amber-500 to-yellow-500',
    pricing: { free: 'Basic price viewing', premium: 'AI predictions + Smart alerts' },
    revenue: 'Rs. 2,200/month - Premium Only',
    features: [
      'AI price movement predictions',
      'Optimal buying time alerts',
      'Seasonal trend analysis',
      'Multi-supplier comparison',
      'Bulk discount finder',
      'Budget optimization AI',
    ],
    technology: 'Predictive Analytics AI',
    accuracy: '89%',
  },
  {
    id: 'smart-scheduler',
    title: 'AI Construction Scheduler',
    description: 'AI-powered project scheduling optimizing timelines, predicting delays, and managing dependencies',
    icon: Cpu,
    color: 'from-indigo-500 to-purple-500',
    pricing: { free: 'Not available in free tier', premium: 'AI-powered scheduling' },
    revenue: 'Rs. 2,500/month - Premium Only',
    features: [
      'AI-generated optimal timelines',
      'Intelligent delay prediction',
      'Weather impact analysis',
      'Smart resource allocation',
      'Critical path optimization',
      'Scenario planning AI',
    ],
    technology: 'Enterprise Scheduling AI',
    accuracy: '91%',
  },
  {
    id: 'document-ai',
    title: 'AI Document & Contract Analyzer',
    description: 'Automatically review contracts, invoices, and documents to flag issues, extract data, and ensure compliance',
    icon: Lock,
    color: 'from-rose-500 to-pink-500',
    pricing: { free: '2 documents only', premium: 'Unlimited AI processing' },
    revenue: 'Rs. 2,400/month or Rs. 400/document',
    features: [
      'AI contract analysis',
      'Automated data extraction',
      'Compliance verification',
      'Risk clause detection',
      'Smart summarization',
      'Multi-language support',
    ],
    technology: 'Enterprise Document AI',
    accuracy: '96%',
  },
  {
    id: 'voice-assistant',
    title: 'AI Voice Assistant (Urdu)',
    description: 'Hands-free voice assistant for contractors on-site to log data, ask questions, and get guidance in Urdu',
    icon: Sparkles,
    color: 'from-teal-500 to-cyan-500',
    pricing: { free: '50 voice commands only', premium: 'Unlimited + offline mode' },
    revenue: 'Rs. 1,800/month or Rs. 200 per 50 commands',
    features: [
      'Advanced Urdu voice AI',
      'Hands-free data logging',
      'Real-time translation',
      'Voice search & queries',
      'Site safety reminders',
      'Offline voice processing',
    ],
    technology: 'Enterprise Voice AI',
    accuracy: '93%',
  },
];

const revenueBreakdown = [
  { feature: 'AI Material Estimator', monthly: 2500, adoption: '35%', total: 875 },
  { feature: 'AI Chatbot Advisor', monthly: 1800, adoption: '55%', total: 990 },
  { feature: 'Theft Detection Engine', monthly: 3500, adoption: '25%', total: 875 },
  { feature: 'Photo Progress Analyzer', monthly: 2800, adoption: '30%', total: 840 },
  { feature: 'Price Predictor', monthly: 2200, adoption: '40%', total: 880 },
  { feature: 'AI Scheduler', monthly: 2500, adoption: '22%', total: 550 },
  { feature: 'Document Analyzer', monthly: 2400, adoption: '18%', total: 432 },
  { feature: 'Voice Assistant', monthly: 1800, adoption: '45%', total: 810 },
];

export default function AIFeaturesView() {
  const [selectedFeature, setSelectedFeature] = useState(aiFeatures[0].id);
  
  const selected = aiFeatures.find(f => f.id === selectedFeature) || aiFeatures[0];
  const totalMonthlyRevenue = revenueBreakdown.reduce((sum, item) => sum + item.total, 0);

  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span className="text-sm text-purple-400 font-medium">Premium AI-Powered Features</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-300 via-pink-300 to-rose-300 bg-clip-text text-transparent">
          Artificial Intelligence
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          8 powerful AI features leveraging Claude, GPT-4, and custom ML models to save money and prevent fraud
        </p>
      </div>

      {/* Revenue Projection */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-3xl p-8"
      >
          <div className="grid md:grid-cols-4 gap-6 mb-6">
          <div className="text-center">
            <DollarSign className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            <div className="text-3xl font-bold text-white mb-1">Rs. {totalMonthlyRevenue.toLocaleString()}</div>
            <div className="text-sm text-slate-400">Additional Monthly Revenue per 1000 Users</div>
          </div>
          <div className="text-center">
            <Bot className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-3xl font-bold text-white mb-1">8</div>
            <div className="text-sm text-slate-400">Premium AI Features</div>
          </div>
          <div className="text-center">
            <Zap className="w-8 h-8 text-amber-400 mx-auto mb-2" />
            <div className="text-3xl font-bold text-white mb-1">98%</div>
            <div className="text-sm text-slate-400">AI Accuracy</div>
          </div>
          <div className="text-center">
            <TrendingUp className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-3xl font-bold text-white mb-1">32%</div>
            <div className="text-sm text-slate-400">Average Premium Adoption</div>
          </div>
        </div>

        <div className="bg-white/10 rounded-2xl p-4">
          <div className="text-sm font-semibold text-emerald-400 mb-3">Revenue Breakdown per Feature</div>
          <div className="space-y-2">
            {revenueBreakdown.map((item, i) => (
              <motion.div
                key={item.feature}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center justify-between text-sm"
              >
                <span className="text-slate-300">{item.feature}</span>
                <div className="flex items-center space-x-3">
                  <span className="text-slate-500">Rs. {item.monthly}/user × {item.adoption} adoption</span>
                  <span className="text-emerald-400 font-semibold min-w-[100px] text-right">
                    = Rs. {item.total.toLocaleString()}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* AI Features Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {aiFeatures.map((feature, index) => (
          <motion.button
            key={feature.id}
            onClick={() => setSelectedFeature(feature.id)}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`p-4 rounded-2xl border transition-all text-left ${
              selectedFeature === feature.id
                ? 'bg-white/10 border-white/20 shadow-xl'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <div className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-3`}>
              <feature.icon className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1">{feature.title}</h3>
            <p className="text-xs text-slate-400">{feature.revenue}</p>
          </motion.button>
        ))}
      </div>

      {/* Selected Feature Detail */}
      <motion.div
        key={selectedFeature}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12"
      >
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-start space-x-4">
            <div className={`w-16 h-16 bg-gradient-to-br ${selected.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
              <selected.icon className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">{selected.title}</h2>
              <p className="text-lg text-slate-300">{selected.description}</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-slate-400 mb-1">Accuracy</div>
            <div className="text-3xl font-bold text-emerald-400">{selected.accuracy}</div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Pricing Tiers</h3>
            <div className="space-y-3">
              <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-400">Free Tier</span>
                  <span className="px-2 py-1 bg-blue-500/20 border border-blue-500/30 rounded-lg text-xs text-blue-400">
                    Rs. 0/month
                  </span>
                </div>
                <p className="text-sm text-slate-300">{selected.pricing.free}</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-purple-400">Premium Tier</span>
                  <span className="px-2 py-1 bg-purple-500/20 border border-purple-500/30 rounded-lg text-xs text-purple-400 font-semibold">
                    {selected.revenue}
                  </span>
                </div>
                <p className="text-sm text-slate-300">{selected.pricing.premium}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Technology Stack</h3>
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-4">
              <div className="flex items-center space-x-2 mb-2">
                <Cpu className="w-5 h-5 text-purple-400" />
                <span className="text-sm font-medium text-white">{selected.technology}</span>
              </div>
              <p className="text-xs text-slate-400">Powered by state-of-the-art machine learning</p>
            </div>
            <div className="flex items-center space-x-2 text-sm text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
              <span>Enterprise-grade AI models</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-emerald-400 mt-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>24/7 AI availability</span>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Premium Features</h3>
          <div className="grid md:grid-cols-2 gap-3">
            {selected.features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-center space-x-2 text-sm text-slate-300"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                <span>{feature}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Why AI Makes MakanGuard Valuable */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Why Premium AI Features Are Worth It</h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: 'Save Rs. 50,000+',
              desc: 'AI theft detection prevents material losses worth lakhs of rupees on your project',
              icon: DollarSign,
              value: '10x ROI',
            },
            {
              title: 'Expert-Level Advice',
              desc: 'Get instant access to AI trained on thousands of construction projects - 24/7 availability',
              icon: TrendingUp,
              value: 'Always Available',
            },
            {
              title: 'Peace of Mind',
              desc: 'AI monitors your project continuously, alerting you instantly to any issues or discrepancies',
              icon: Lock,
              value: '24/7 Protection',
            },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-center space-y-3"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto">
                <item.icon className="w-8 h-8 text-white" />
              </div>
              <div className="text-2xl font-bold text-amber-400">{item.value}</div>
              <h4 className="text-lg font-semibold text-white">{item.title}</h4>
              <p className="text-sm text-slate-400">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="inline-block bg-gradient-to-r from-rose-500/20 to-orange-500/20 border border-rose-500/30 rounded-2xl p-6">
          <h3 className="text-2xl font-bold text-white mb-2">Limited Free Trial</h3>
          <p className="text-slate-300 mb-4">Try before you buy - limited AI usage included free:</p>
          <div className="grid md:grid-cols-4 gap-3 text-sm mb-4">
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-emerald-400 font-bold">2</div>
              <div className="text-slate-400">AI Estimates</div>
            </div>
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-emerald-400 font-bold">20</div>
              <div className="text-slate-400">Chatbot Messages</div>
            </div>
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-emerald-400 font-bold">5</div>
              <div className="text-slate-400">Photo Analyses</div>
            </div>
            <div className="bg-white/5 rounded-lg p-2">
              <div className="text-emerald-400 font-bold">50</div>
              <div className="text-slate-400">Voice Commands</div>
            </div>
          </div>
          <p className="text-xs text-amber-400">⚠️ After free trial ends, unlock unlimited AI for Rs. 5,999/month</p>
        </div>

        <motion.button
          className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl text-white font-semibold text-lg shadow-lg shadow-purple-500/50"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5" />
            <span>Unlock Unlimited AI - Rs. 5,999/month</span>
          </div>
        </motion.button>
        <p className="text-sm text-slate-400">All 8 AI features • Unlimited usage • Cancel anytime • Save Rs. 50,000+ on theft prevention</p>
      </motion.div>
    </div>
  );
}
