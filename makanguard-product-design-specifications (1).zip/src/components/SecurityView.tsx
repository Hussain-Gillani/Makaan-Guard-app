'use client';

import { motion } from 'framer-motion';
import { Shield, Lock, Key, Eye, Database, FileCheck, UserCheck, AlertTriangle, CheckCircle2, Smartphone } from 'lucide-react';

const securityLayers = [
  {
    title: 'Authentication & Authorization',
    icon: Key,
    color: 'from-blue-500 to-cyan-500',
    measures: [
      { name: 'JWT Token-Based Auth', desc: 'Secure token authentication with refresh mechanism', icon: Key },
      { name: 'Multi-Factor Authentication', desc: 'SMS OTP via JazzCash/Easypaisa for sensitive actions', icon: Smartphone },
      { name: 'Role-Based Access Control', desc: 'Granular permissions for Owner, Contractor, Supervisor', icon: UserCheck },
      { name: 'Session Management', desc: 'Auto-logout after inactivity, device tracking', icon: Lock },
    ],
  },
  {
    title: 'Data Protection',
    icon: Database,
    color: 'from-purple-500 to-pink-500',
    measures: [
      { name: 'End-to-End Encryption', desc: 'All data encrypted in transit (TLS 1.3) and at rest (AES-256)', icon: Lock },
      { name: 'Photo Privacy', desc: 'Photos watermarked with timestamp, GPS, never shareable publicly', icon: Eye },
      { name: 'PII Protection', desc: 'Phone numbers, addresses, financial data fully encrypted', icon: Shield },
      { name: 'Backup & Recovery', desc: 'Automated daily backups with 30-day retention', icon: Database },
    ],
  },
  {
    title: 'Application Security',
    icon: Shield,
    color: 'from-green-500 to-emerald-500',
    measures: [
      { name: 'Input Validation', desc: 'All user inputs sanitized, SQL injection prevention', icon: FileCheck },
      { name: 'Rate Limiting', desc: 'API rate limits to prevent abuse and DDoS', icon: AlertTriangle },
      { name: 'Code Security', desc: 'Regular security audits, dependency scanning', icon: CheckCircle2 },
      { name: 'Secure Storage', desc: 'Sensitive keys in AWS Secrets Manager, never hardcoded', icon: Key },
    ],
  },
  {
    title: 'Access Control',
    icon: UserCheck,
    color: 'from-orange-500 to-red-500',
    measures: [
      { name: 'Project-Level Permissions', desc: 'Users can only access their own project data', icon: Lock },
      { name: 'Contractor Limited Access', desc: 'Contractors see only current task, not full budget', icon: Eye },
      { name: 'Audit Trails', desc: 'Every action logged with user, timestamp, IP address', icon: FileCheck },
      { name: 'Invite-Only Access', desc: 'Contractors/supervisors must be invited by owner', icon: UserCheck },
    ],
  },
];

const complianceStandards = [
  { name: 'GDPR Ready', desc: 'Data privacy and right to deletion', icon: Shield },
  { name: 'PCI DSS', desc: 'Payment card industry standards', icon: Lock },
  { name: 'SOC 2 Type II', desc: 'Security, availability, confidentiality', icon: CheckCircle2 },
  { name: 'ISO 27001', desc: 'Information security management', icon: FileCheck },
];

const threatMitigation = [
  {
    threat: 'Material Theft by Contractor',
    mitigation: 'Automated discrepancy alerts, photo verification, GPS tracking',
    severity: 'Critical',
    color: 'from-red-500 to-rose-500',
  },
  {
    threat: 'Unauthorized Data Access',
    mitigation: 'JWT authentication, RBAC, encryption, audit logs',
    severity: 'High',
    color: 'from-orange-500 to-amber-500',
  },
  {
    threat: 'Payment Fraud',
    mitigation: 'Milestone-based release, photo proof, MFA for payments',
    severity: 'Critical',
    color: 'from-red-500 to-rose-500',
  },
  {
    threat: 'Account Takeover',
    mitigation: 'SMS OTP, device tracking, suspicious login alerts',
    severity: 'High',
    color: 'from-orange-500 to-amber-500',
  },
  {
    threat: 'Data Breach',
    mitigation: 'Encryption at rest and in transit, regular security audits',
    severity: 'Critical',
    color: 'from-red-500 to-rose-500',
  },
  {
    threat: 'Price Manipulation',
    mitigation: 'Multiple data sources, manual verification, rate limiting',
    severity: 'Medium',
    color: 'from-yellow-500 to-orange-500',
  },
];

export default function SecurityView() {
  return (
    <div className="space-y-12">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          className="inline-flex items-center space-x-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Shield className="w-4 h-4 text-red-400" />
          <span className="text-sm text-red-400 font-medium">Security & Access Control</span>
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-red-300 via-rose-300 to-pink-300 bg-clip-text text-transparent">
          Security Architecture
        </h1>
        
        <p className="text-xl text-slate-300 max-w-3xl mx-auto">
          Multi-layered security protecting homeowners' most valuable investment
        </p>
      </div>

      {/* Security Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-red-500/10 to-rose-500/10 border border-red-500/20 rounded-3xl p-8 md:p-12"
      >
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { label: 'Security Layers', value: '4+', icon: Layers },
            { label: 'Encryption Standard', value: 'AES-256', icon: Lock },
            { label: 'Auth Protocol', value: 'JWT + MFA', icon: Key },
            { label: 'Audit Logging', value: '100%', icon: FileCheck },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="text-center space-y-2"
            >
              <stat.icon className="w-8 h-8 text-red-400 mx-auto" />
              <div className="text-3xl font-bold text-white">{stat.value}</div>
              <div className="text-sm text-slate-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Security Layers */}
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">Security Layers</h2>
        
        <div className="grid gap-8">
          {securityLayers.map((layer, index) => (
            <motion.div
              key={layer.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 md:p-8 hover:bg-white/10 transition-all"
            >
              <div className="flex items-center space-x-4 mb-6">
                <div className={`w-14 h-14 bg-gradient-to-br ${layer.color} rounded-xl flex items-center justify-center`}>
                  <layer.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white">{layer.title}</h3>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {layer.measures.map((measure, i) => (
                  <motion.div
                    key={measure.name}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 + i * 0.05 }}
                    className="bg-white/5 border border-white/10 rounded-xl p-4 hover:border-emerald-500/30 transition-all group"
                  >
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:bg-emerald-500/30 transition-colors">
                        <measure.icon className="w-5 h-5 text-emerald-400" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-white font-semibold mb-1">{measure.name}</h4>
                        <p className="text-xs text-slate-400">{measure.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Threat Mitigation */}
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">Threat Mitigation</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          {threatMitigation.map((threat, index) => (
            <motion.div
              key={threat.threat}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-5 h-5 text-rose-400" />
                  <h3 className="text-lg font-bold text-white">{threat.threat}</h3>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${threat.color} text-white`}>
                  {threat.severity}
                </span>
              </div>
              
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-slate-300">{threat.mitigation}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Compliance Standards */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 rounded-3xl p-8 md:p-12"
      >
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Compliance Standards</h2>
        
        <div className="grid md:grid-cols-4 gap-6">
          {complianceStandards.map((standard, i) => (
            <motion.div
              key={standard.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-6 text-center hover:bg-white/10 transition-all group"
            >
              <div className="w-12 h-12 bg-indigo-500/20 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <standard.icon className="w-6 h-6 text-indigo-400" />
              </div>
              <h4 className="text-white font-bold mb-2">{standard.name}</h4>
              <p className="text-xs text-slate-400">{standard.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Privacy Principles */}
      <div className="grid md:grid-cols-3 gap-6">
        {[
          {
            title: 'Data Ownership',
            desc: 'Homeowners own all their data. Full export and deletion available anytime.',
            icon: Database,
          },
          {
            title: 'Transparency',
            desc: 'Clear consent for data collection. No hidden tracking or third-party sharing.',
            icon: Eye,
          },
          {
            title: 'Minimal Collection',
            desc: 'Only collect data essential for core functionality. No unnecessary surveillance.',
            icon: Shield,
          },
        ].map((principle, i) => (
          <motion.div
            key={principle.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-center hover:bg-white/10 transition-all"
          >
            <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mx-auto mb-4">
              <principle.icon className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-lg font-bold text-white mb-3">{principle.title}</h3>
            <p className="text-sm text-slate-400">{principle.desc}</p>
          </motion.div>
        ))}
      </div>

      {/* Access Control Matrix */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 overflow-x-auto"
      >
        <h2 className="text-2xl font-bold text-white mb-6 text-center">Access Control Matrix</h2>
        
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/10">
              <th className="text-left py-3 px-4 text-slate-400 font-medium">Feature</th>
              <th className="text-center py-3 px-4 text-emerald-400 font-medium">Owner</th>
              <th className="text-center py-3 px-4 text-blue-400 font-medium">Contractor</th>
              <th className="text-center py-3 px-4 text-purple-400 font-medium">Supervisor</th>
            </tr>
          </thead>
          <tbody>
            {[
              { feature: 'View Budget', owner: true, contractor: false, supervisor: false },
              { feature: 'Log Deliveries', owner: true, contractor: true, supervisor: true },
              { feature: 'Log Usage', owner: false, contractor: true, supervisor: true },
              { feature: 'Upload Photos', owner: true, contractor: true, supervisor: true },
              { feature: 'View Alerts', owner: true, contractor: false, supervisor: true },
              { feature: 'Release Payments', owner: true, contractor: false, supervisor: false },
              { feature: 'Invite Users', owner: true, contractor: false, supervisor: false },
              { feature: 'View Material Estimates', owner: true, contractor: false, supervisor: true },
            ].map((row, i) => (
              <tr key={row.feature} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="py-3 px-4 text-white">{row.feature}</td>
                <td className="py-3 px-4 text-center">
                  {row.owner ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto" />
                  ) : (
                    <div className="w-5 h-5 border-2 border-slate-600 rounded-full mx-auto" />
                  )}
                </td>
                <td className="py-3 px-4 text-center">
                  {row.contractor ? (
                    <CheckCircle2 className="w-5 h-5 text-blue-400 mx-auto" />
                  ) : (
                    <div className="w-5 h-5 border-2 border-slate-600 rounded-full mx-auto" />
                  )}
                </td>
                <td className="py-3 px-4 text-center">
                  {row.supervisor ? (
                    <CheckCircle2 className="w-5 h-5 text-purple-400 mx-auto" />
                  ) : (
                    <div className="w-5 h-5 border-2 border-slate-600 rounded-full mx-auto" />
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </div>
  );
}

function Layers({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
