'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, X, DollarSign, Shield, Zap, TrendingUp } from 'lucide-react';

interface HeroSectionProps {
  onClose: () => void;
  onNavigate: (view: string) => void;
}

export default function HeroSection({ onClose, onNavigate }: HeroSectionProps) {
  const [show, setShow] = useState(true);

  useEffect(() => {
    // Auto-hide after 10 seconds
    const timer = setTimeout(() => {
      setShow(false);
      onClose();
    }, 10000);

    return () => clearTimeout(timer);
  }, [onClose]);

  const handleClose = () => {
    setShow(false);
    setTimeout(onClose, 300);
  };

  const handleNavigate = (view: string) => {
    setShow(false);
    setTimeout(() => {
      onNavigate(view);
      onClose();
    }, 300);
  };

  if (!show) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl"
        onClick={handleClose}
      >
        <motion.div
          initial={{ scale: 0.8, y: 50, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.8, y: 50, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          onClick={(e) => e.stopPropagation()}
          className="relative max-w-4xl w-full bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 border-2 border-emerald-500/30 rounded-3xl overflow-hidden"
        >
          {/* Close Button */}
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full transition-colors z-10"
          >
            <X className="w-6 h-6 text-slate-400" />
          </button>

          {/* Animated Background */}
          <div className="absolute inset-0 overflow-hidden">
            <motion.div
              className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-emerald-500/10 to-transparent rounded-full blur-3xl"
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 90, 0],
              }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            />
            <motion.div
              className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-teal-500/10 to-transparent rounded-full blur-3xl"
              animate={{
                scale: [1.2, 1, 1.2],
                rotate: [90, 0, 90],
              }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            />
          </div>

          {/* Content */}
          <div className="relative p-12 text-center space-y-8">
            {/* Icon */}
            <motion.div
              className="w-24 h-24 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/50"
              animate={{
                rotate: [0, 5, -5, 0],
                scale: [1, 1.05, 1],
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Shield className="w-12 h-12 text-white" />
            </motion.div>

            {/* Title with Sparkles */}
            <div className="space-y-4">
              <motion.div
                className="flex items-center justify-center space-x-3"
                animate={{ opacity: [0.7, 1, 0.7] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Sparkles className="w-6 h-6 text-emerald-400" />
                <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-emerald-300 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
                  MakanGuard
                </h1>
                <Sparkles className="w-6 h-6 text-emerald-400" />
              </motion.div>

              <p className="text-2xl md:text-3xl text-white font-semibold">
                AI-Powered Construction Guardian
              </p>

              <p className="text-lg text-slate-300 max-w-2xl mx-auto">
                Stop losing 25-40% of your construction budget to theft and fraud. 
                Protect your dream home with enterprise-grade AI monitoring.
              </p>
            </div>

            {/* Key Features */}
            <div className="grid md:grid-cols-4 gap-4">
              {[
                { icon: Zap, label: '8 AI Features', value: 'Enterprise AI', color: 'from-purple-500 to-pink-500' },
                { icon: Shield, label: 'Theft Detection', value: '92% Accuracy', color: 'from-red-500 to-orange-500' },
                { icon: DollarSign, label: 'Save Money', value: 'Rs. 50K+', color: 'from-green-500 to-emerald-500' },
                { icon: TrendingUp, label: 'User Savings', value: '25-40% Budget', color: 'from-blue-500 to-cyan-500' },
              ].map((item, i) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                  className={`bg-gradient-to-br ${item.color} bg-opacity-10 border border-white/20 rounded-2xl p-4`}
                >
                  <item.icon className="w-8 h-8 text-white mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white mb-1">{item.value}</div>
                  <div className="text-xs text-slate-300">{item.label}</div>
                </motion.div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <motion.button
                onClick={() => handleNavigate('ai')}
                className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl text-white font-semibold text-lg shadow-2xl shadow-purple-500/50 flex items-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                animate={{
                  boxShadow: [
                    '0 20px 60px rgba(168, 85, 247, 0.3)',
                    '0 20px 80px rgba(168, 85, 247, 0.5)',
                    '0 20px 60px rgba(168, 85, 247, 0.3)',
                  ],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Sparkles className="w-5 h-5" />
                <span>Explore AI Features</span>
                <ArrowRight className="w-5 h-5" />
              </motion.button>

              <motion.button
                onClick={() => handleNavigate('payment')}
                className="px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold text-lg shadow-2xl shadow-emerald-500/50 flex items-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <DollarSign className="w-5 h-5" />
                <span>View Pricing</span>
                <ArrowRight className="w-5 h-5" />
              </motion.button>

              <motion.button
                onClick={() => handleNavigate('revenue')}
                className="px-8 py-4 bg-white/10 border border-white/20 rounded-xl text-white font-semibold hover:bg-white/20 transition-all flex items-center space-x-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <TrendingUp className="w-5 h-5" />
                <span>Revenue Model</span>
              </motion.button>
            </div>

            {/* Auto-dismiss timer */}
            <div className="pt-4">
              <div className="text-xs text-slate-500 mb-2">Auto-closing in 10 seconds...</div>
              <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
                  initial={{ width: '100%' }}
                  animate={{ width: '0%' }}
                  transition={{ duration: 10, ease: 'linear' }}
                />
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
