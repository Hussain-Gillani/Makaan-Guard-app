import { pgTable, text, serial, integer, timestamp, boolean, decimal, jsonb } from 'drizzle-orm/pg-core';

// Projects table
export const projects = pgTable('projects', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  plotSize: decimal('plot_size').notNull(),
  plotUnit: text('plot_unit').notNull(), // marla/kanal
  floors: integer('floors').notNull(),
  houseType: text('house_type').notNull(),
  city: text('city').notNull(),
  status: text('status').notNull().default('active'),
  ownerName: text('owner_name'),
  ownerPhone: text('owner_phone'),
  isOverseas: boolean('is_overseas').default(false),
  estimatedBudget: decimal('estimated_budget'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Material estimates
export const materialEstimates = pgTable('material_estimates', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').notNull().references(() => projects.id),
  materialType: text('material_type').notNull(),
  materialName: text('material_name').notNull(),
  estimatedQuantity: decimal('estimated_quantity').notNull(),
  unit: text('unit').notNull(),
  currentPrice: decimal('current_price'),
  estimatedCost: decimal('estimated_cost'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Material deliveries
export const deliveries = pgTable('deliveries', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').notNull().references(() => projects.id),
  materialType: text('material_type').notNull(),
  materialName: text('material_name').notNull(),
  quantity: decimal('quantity').notNull(),
  unit: text('unit').notNull(),
  supplierName: text('supplier_name'),
  invoicePhoto: text('invoice_photo'),
  stackPhoto: text('stack_photo'),
  gpsLocation: text('gps_location'),
  deliveryDate: timestamp('delivery_date').notNull(),
  recordedBy: text('recorded_by'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Daily usage logs
export const usageLogs = pgTable('usage_logs', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').notNull().references(() => projects.id),
  materialType: text('material_type').notNull(),
  materialName: text('material_name').notNull(),
  quantity: decimal('quantity').notNull(),
  unit: text('unit').notNull(),
  usageDate: timestamp('usage_date').notNull(),
  workDescription: text('work_description'),
  recordedBy: text('recorded_by'),
  voiceNoteUrl: text('voice_note_url'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Progress photos
export const progressPhotos = pgTable('progress_photos', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').notNull().references(() => projects.id),
  photoUrl: text('photo_url').notNull(),
  caption: text('caption'),
  voiceCaption: text('voice_caption'),
  gpsLocation: text('gps_location'),
  uploadedBy: text('uploaded_by'),
  photoDate: timestamp('photo_date').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Discrepancy alerts
export const alerts = pgTable('alerts', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').notNull().references(() => projects.id),
  alertType: text('alert_type').notNull(), // theft_warning, price_drop, milestone_delay
  severity: text('severity').notNull(), // low, medium, high
  title: text('title').notNull(),
  description: text('description').notNull(),
  suggestedAction: text('suggested_action'),
  metadata: jsonb('metadata'),
  isRead: boolean('is_read').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// Feature tickets for roadmap
export const featureTickets = pgTable('feature_tickets', {
  id: serial('id').primaryKey(),
  scope: integer('scope').notNull(), // 1-6
  title: text('title').notNull(),
  description: text('description').notNull(),
  priority: text('priority').notNull(), // critical, high, medium, low
  status: text('status').notNull().default('planned'), // planned, in_progress, completed
  estimatedDays: integer('estimated_days'),
  dependencies: text('dependencies'),
  acceptanceCriteria: text('acceptance_criteria'),
  createdAt: timestamp('created_at').defaultNow(),
});
