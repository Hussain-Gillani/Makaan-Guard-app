# MakanGuard Design System

## Overview
A calm, vigilant mobile app acting as a digital guardian for Pakistani homeowners building their dream house. The design follows a respectful, trustworthy aesthetic with modern UI patterns.

## Color Palette

### Primary Colors
- **Emerald 500**: `#10b981` - Primary actions, success states, trust
- **Teal 500**: `#14b8a6` - Secondary accents, links, progress indicators

### Semantic Colors
- **Rose 500**: `#f43f5e` - Alerts, critical warnings, theft detection
- **Amber 500**: `#f59e0b` - Warnings, caution states, price alerts
- **Blue 500**: `#3b82f6` - Information, links, overseas features
- **Purple 500**: `#a855f7` - Premium features, AI capabilities

### Neutral Colors
- **Slate 950**: `#020617` - Background, dark surfaces
- **Slate 900**: `#0f172a` - Card backgrounds
- **Slate 100-700**: Text variations and borders

## Typography

### Font Family
- **Inter**: Primary font for Latin text
- **Noto Nastaliq Urdu**: For Urdu language support

### Scale
- **Display**: 48-72px, Bold - Hero headlines
- **Heading 1**: 36-48px, Bold - Section titles
- **Heading 2**: 24-32px, Semibold - Card titles
- **Body**: 16px, Regular - Main content
- **Caption**: 12-14px, Medium - Labels, metadata

## Spacing System
- **Base Unit**: 4px
- **Scale**: 0, 4, 8, 12, 16, 24, 32, 48, 64px

## Components

### Buttons
- **Primary**: Gradient emerald-teal, rounded-xl, shadow on hover
- **Secondary**: White/10 background, border, subtle hover
- **Danger**: Rose gradient for destructive actions

### Cards
- **Background**: White/5 backdrop-blur-xl
- **Border**: White/10 opacity
- **Hover**: Scale 1.02x with shadow expansion
- **Rounded**: 16px corners

### Inputs
- **Background**: White/10
- **Border**: White/20
- **Focus**: Emerald border glow
- **Rounded**: 12px corners

## Screens

### 1. Onboarding
- 4-step setup wizard
- Plot size selector (marla/kanal)
- House type selection
- City picker

### 2. Dashboard
- Progress overview with percentage bar
- Quick action buttons (4-grid)
- Recent activity feed
- Location display

### 3. Estimator
- Material quantity list
- Price breakdown
- Total cost display
- Download report button

### 4. Delivery Log
- Photo-first interface
- Material type selector
- Quantity input
- GPS auto-tagging

### 5. Price Tracker
- Live price cards with trend indicators
- Price drop alerts
- Supplier comparison

### 6. Alerts
- Calm notification cards
- Severity color coding
- Suggested actions

## Animations
- **Page Transitions**: 300ms fade + slide
- **Hover Effects**: 1.02x scale with shadow
- **Progress Bars**: Animated width
- **Staggered Lists**: 50ms delay between items

## Target Platforms
- **Mobile-first**: iOS and Android
- **Responsive**: Tablet and desktop support
- **Offline**: Full functionality without connection

## User Personas
1. **Local Homeowners**: Visiting site regularly
2. **Overseas Pakistanis**: Building from abroad
3. **Contractors**: Managing construction work

## Export Notes
This design system is ready for Google AI Studio integration. The components follow a consistent design language optimized for React Native development with web preview support.