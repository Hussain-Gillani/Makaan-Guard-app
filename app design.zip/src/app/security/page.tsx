'use client';

import { motion } from 'framer-motion';
import { Lock, Shield, Key, Eye, AlertTriangle, CheckCircle2 } from 'lucide-react';

const securityLayers = [
  {
    id: 1,
    title: 'Authentication & Authorization',
    description: 'JWT tokens with refresh, SMS OTP via JazzCash, Role-based access control',
    icon: Key,
    color: 'from-blue-500 to-cyan-500',
    features: ['JWT tokens with refresh', 'SMS OTP via JazzCash', 'Role-based access control', 'Session management']
  },
  {
    id: 2,
    title: 'Data Protection',
    description: 'End-to-end encryption, photo watermarking, PII protection, automated backups',
    icon: Lock,
    color: 'from-green-500 to-emerald-500',
    features: ['End-to-end encryption (AES-256)', 'Photo watermarking', 'PII protection', 'Automated backups']
  },
  {
    id: 3,
    title: 'Application Security',
    description: 'Input validation, rate limiting, code security audits, secure key storage',
    icon: Shield,
    color: 'from-purple-500 to-pink-500',
    features: ['Input validation', 'Rate limiting', 'Code security audits', 'Secure key storage']
  },
  {
    id: 4,
    title: 'Access Control',
    description: 'Project-level permissions, contractor limited access, audit trails, invite-only system',
    icon: Eye,
    color: 'from-orange-500 to-red-500',
    features: ['Project-level permissions', 'Contractor limited access', 'Audit trails', 'Invite-only system']
  }
];

const rolePermissions = [
  { feature: 'View Budget', owner: true, contractor: false, supervisor: false },
  { feature: 'Log Deliveries', owner: true, contractor: true, supervisor: true },
  { feature: 'Log Usage', owner: false, contractor: true, supervisor: true },
  { feature: 'View Alerts', owner: true, contractor: false, supervisor: true },
  { feature: 'Release Payments', owner: true, contractor: false, supervisor: false }
];

export default function SecurityPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-6 py-20">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <motion.div
            className="inline-flex items-center space-x-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Lock className="w-4 h-4 text-red-400" />
            <span className="text-sm text-red-400 font-medium">Security Architecture</span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-red-300 via-rose-300 to-pink-300 bg-clip-text text-transparent">
            Multi-Layer Security
          </h1>
          
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Four security layers protecting your construction data and payments
          </p>
        </div>

        {/* Security Layers */}
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {securityLayers.map((layer, index) => (
            <motion.div
              key={layer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
            >
              <div className={`w-14 h-14 bg-gradient-to-br ${layer.color} rounded-2xl flex items-center justify-center mb-4`}>
                <layer.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{layer.title}</h3>
              <p className="text-slate-400 mb-4">{layer.description}</p>
              <div className="space-y-2">
                {layer.features.map((feature) => (
                  <div key={feature} className="flex items-center space-x-2 text-sm text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Role-Based Access Control */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Role-Based Permissions</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left py-3 px-4 text-slate-400">Feature</th>
                  <th className="text-center py-3 px-4 text-emerald-400">Owner</th>
                  <th className="text-center py-3 px-4 text-blue-400">Contractor</th>
                  <th className="text-center py-3 px-4 text-orange-400">Supervisor</th>
                </tr>
              </thead>
              <tbody>
                {rolePermissions.map((row) => (
                  <tr key={row.feature} className="border-b border-white/5">
                    <td className="py-3 px-4 text-white">{row.feature}</td>
                    <td className="text-center py-3 px-4">{row.owner ? '✅' : '❌'}</td>
                    <td className="text-center py-3 px-4">{row.contractor ? '✅' : '❌'}</td>
                    <td className="text-center py-3 px-4">{row.supervisor ? '✅' : '❌'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Compliance */}
        <div className="grid md:grid-cols-3 gap-6">
          {['GDPR Compliant', 'P@SHA Certified', 'Bank-Grade Security', 'ISO 27001'].map((item, i) => (
            <motion.div
              key={item}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-2xl p-6 text-center"
            >
              <Shield className="w-10 h-10 text-emerald-400 mx-auto mb-4" />
              <div className="text-white font-semibold">{item}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}