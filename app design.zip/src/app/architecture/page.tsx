'use client';

import { motion } from 'framer-motion';
import { Cpu, Database, Cloud, Shield, Zap, Upload } from 'lucide-react';

const techStack = [
  { category: 'Frontend', items: ['Next.js 16', 'React 19', 'Tailwind CSS 4', 'Framer Motion'], icon: Zap, color: 'from-blue-500 to-cyan-500' },
  { category: 'Backend', items: ['Node.js', 'PostgreSQL', 'Drizzle ORM', 'Redis'], icon: Cpu, color: 'from-green-500 to-emerald-500' },
  { category: 'Infrastructure', items: ['AWS EC2', 'RDS', 'S3', 'CloudFront'], icon: Cloud, color: 'from-purple-500 to-pink-500' },
  { category: 'Security', items: ['JWT Auth', 'AES-256', 'TLS 1.3', 'SMS OTP'], icon: Shield, color: 'from-red-500 to-orange-500' }
];

export default function ArchitecturePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-6 py-20">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <motion.div
            className="inline-flex items-center space-x-2 px-4 py-2 bg-orange-500/10 border border-orange-500/20 rounded-full"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Cpu className="w-4 h-4 text-orange-400" />
            <span className="text-sm text-orange-400 font-medium">Technical Architecture</span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-orange-300 via-red-300 to-rose-300 bg-clip-text text-transparent">
            System Design
          </h1>
          
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Complete architecture for scalable construction monitoring platform
          </p>
        </div>

        {/* Architecture Layers */}
        <div className="space-y-12">
          {/* Layer Diagram */}
          <div className="relative">
            <div className="grid md:grid-cols-4 gap-8">
              {[
                { name: 'Presentation', desc: 'Next.js Frontend', icon: Zap, color: 'from-blue-500 to-cyan-500' },
                { name: 'Application', desc: 'Node.js API', icon: Cpu, color: 'from-green-500 to-emerald-500' },
                { name: 'Data', desc: 'PostgreSQL + Redis', icon: Database, color: 'from-purple-500 to-pink-500' },
                { name: 'Infrastructure', desc: 'AWS Cloud', icon: Cloud, color: 'from-orange-500 to-red-500' }
              ].map((layer, i) => (
                <motion.div
                  key={layer.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="text-center space-y-4"
                >
                  <div className={`w-20 h-20 bg-gradient-to-br ${layer.color} rounded-2xl flex items-center justify-center mx-auto shadow-lg`}>
                    <layer.icon className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white">{layer.name}</h3>
                  <p className="text-slate-400">{layer.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Tech Stack Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {techStack.map((stack, index) => (
              <motion.div
                key={stack.category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
              >
                <stack.icon className={`w-10 h-10 text-emerald-400 mb-4`} />
                <h3 className="text-lg font-bold text-white mb-3">{stack.category}</h3>
                <div className="space-y-2">
                  {stack.items.map((item) => (
                    <div key={item} className="text-sm text-slate-400">{item}</div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Performance Metrics */}
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { value: '<100ms', label: 'API Response Time', icon: Zap },
              { value: '<3s', label: 'Photo Upload Time', icon: Upload },
              { value: '100%', label: 'Offline Support', icon: Shield }
            ].map((metric, i) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-2xl p-8 text-center"
              >
                <metric.icon className="w-10 h-10 text-emerald-400 mx-auto mb-4" />
                <div className="text-4xl font-bold text-white mb-2">{metric.value}</div>
                <div className="text-slate-400">{metric.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}