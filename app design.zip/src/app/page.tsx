'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { 
  Shield, Home, Package, TrendingDown, Camera, Bell, 
  Users, Globe, DollarSign, CheckCircle2, ArrowRight,
  Building2, Wrench, BarChart3, MapPin, Phone, Search,
  Star, Zap, Lock, Heart, Target, Clock, AlertTriangle
} from 'lucide-react';

export default function MakanGuardLanding() {
  const [showHero, setShowHero] = useState(true);
  const [activeScreen, setActiveScreen] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setShowHero(false), 10000);
    return () => clearTimeout(timer);
  }, []);

  // Mobile app screens data
  const screens = [
    {
      name: 'Dashboard',
      component: <DashboardScreen />,
      color: 'from-emerald-500 to-teal-500'
    },
    {
      name: 'Estimator',
      component: <EstimatorScreen />,
      color: 'from-purple-500 to-pink-500'
    },
    {
      name: 'Delivery Log',
      component: <DeliveryScreen />,
      color: 'from-orange-500 to-red-500'
    },
    {
      name: 'Price Tracker',
      component: <PriceTrackerScreen />,
      color: 'from-blue-500 to-cyan-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-emerald-500/5 to-transparent rounded-full blur-3xl"
          animate={{ scale: [1, 1.2, 1], rotate: [0, 90, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        <motion.div
          className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-blue-500/5 to-transparent rounded-full blur-3xl"
          animate={{ scale: [1.2, 1, 1.2], rotate: [90, 0, 90] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* Hero Section - Stitch AI Style */}
      <AnimatePresence>
        {showHero && (
          <motion.section
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative min-h-screen flex items-center justify-center"
          >
            <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/10 to-transparent" />
            
            <div className="relative max-w-7xl mx-auto px-6 py-20 text-center">
              {/* Logo Badge */}
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="inline-flex items-center space-x-2 px-6 py-3 bg-white/10 border border-white/20 rounded-full mb-8"
              >
                <Shield className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-medium text-emerald-400">AI-Powered Construction Guardian</span>
              </motion.div>

              {/* Main Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-5xl md:text-7xl font-bold mb-6"
              >
                <span className="bg-gradient-to-r from-emerald-300 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
                  MakanGuard
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto mb-12"
              >
                Stop losing 25-40% of your construction budget to theft and fraud.
                Your dream home deserves a digital guardian.
              </motion.p>

              {/* Stats Grid - Like Griyo Real Estate */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-16"
              >
                {[
                  { value: '800K-1M', label: 'Houses Built Annually', icon: Home },
                  { value: '25-40%', label: 'Average Budget Loss', icon: TrendingDown },
                  { value: '10M+', label: 'Overseas Pakistanis', icon: Globe },
                  { value: '$35B', label: 'Annual Remittances', icon: DollarSign }
                ].map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                    className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all"
                  >
                    <stat.icon className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
                    <div className="text-3xl font-bold text-white">{stat.value}</div>
                    <div className="text-sm text-slate-400">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="flex flex-col sm:flex-row gap-4 justify-center"
              >
                <Link href="/app">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold text-lg shadow-2xl shadow-emerald-500/50 flex items-center space-x-2"
                  >
                    <span>Get Started Free</span>
                    <ArrowRight className="w-5 h-5" />
                  </motion.button>
                </Link>
                <Link href="/features">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-white/10 border border-white/20 rounded-xl text-white font-semibold hover:bg-white/20 transition-all flex items-center space-x-2"
                  >
                    <span>View Features</span>
                  </motion.button>
                </Link>
              </motion.div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="relative">
        {/* Features Section */}
        <section className="py-20 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Six Powerful Features
              </h2>
              <p className="text-slate-400 max-w-2xl mx-auto">
                Sequential scopes that deliver standalone value and build habit
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Package,
                  title: 'Smart Estimator',
                  desc: 'Instant material quantities and cost estimates in 5 minutes',
                  color: 'from-blue-500 to-cyan-500'
                },
                {
                  icon: TrendingDown,
                  title: 'Price Tracker',
                  desc: 'Daily price updates with drop alerts to save money',
                  color: 'from-green-500 to-emerald-500'
                },
                {
                  icon: Camera,
                  title: 'Delivery Log',
                  desc: '30-second photo-first logging with GPS tagging',
                  color: 'from-purple-500 to-pink-500'
                },
                {
                  icon: Shield,
                  title: 'Anti-Theft Engine',
                  desc: 'Silent discrepancy detection protecting your investment',
                  color: 'from-orange-500 to-red-500'
                },
                {
                  icon: Globe,
                  title: 'Progress Journal',
                  desc: 'Daily photos and weekly collages for overseas users',
                  color: 'from-indigo-500 to-purple-500'
                },
                {
                  icon: DollarSign,
                  title: 'Milestone Payments',
                  desc: 'Secure payments after verification with JazzCash integration',
                  color: 'from-teal-500 to-cyan-500'
                }
              ].map((feature, i) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white/5 border border-white/10 rounded-3xl p-8 hover:bg-white/10 transition-all group"
                >
                  <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <feature.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                  <p className="text-slate-400">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* App Screens Preview - Stitch AI Style */}
        <section className="py-20 px-6 bg-slate-900/50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Interactive Mobile App
              </h2>
              <p className="text-slate-400 max-w-2xl mx-auto">
                Built for Pakistani homeowners and overseas Pakistanis
              </p>
            </div>

            <div className="flex justify-center">
              <div className="relative">
                {/* Phone Frame */}
                <div className="relative bg-slate-900 rounded-[3rem] p-3 shadow-2xl shadow-emerald-500/20 border-4 border-slate-800">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-20" />
                  <div className="bg-slate-950 rounded-[2.5rem] overflow-hidden h-[600px] w-[320px]">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={activeScreen}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.3 }}
                        className="h-full overflow-y-auto"
                      >
                        {screens[activeScreen].component}
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </div>
              </div>
            </div>

            {/* Screen Selector */}
            <div className="flex justify-center mt-12 space-x-4">
              {screens.map((screen, i) => (
                <button
                  key={screen.name}
                  onClick={() => setActiveScreen(i)}
                  className={`px-6 py-3 rounded-xl border transition-all ${
                    activeScreen === i
                      ? 'bg-white/10 border-white/20 shadow-lg'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <span className="text-sm font-medium text-white">{screen.name}</span>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-3xl p-12">
              <h2 className="text-4xl font-bold text-white mb-4">
                Ready to Protect Your Dream Home?
              </h2>
              <p className="text-slate-300 mb-8">
                Join thousands of homeowners saving money and preventing theft
              </p>
              <Link href="/app">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-10 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold text-lg shadow-2xl shadow-emerald-500/50"
                >
                  Start Free Trial
                </motion.button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-emerald-300 to-teal-300 bg-clip-text text-transparent">
              MakanGuard
            </span>
          </div>
          <p className="text-slate-400 text-sm">
            Protecting your dream home, one brick at a time.
          </p>
        </div>
      </footer>
    </div>
  );
}

// Mobile App Screens
function DashboardScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2 text-emerald-400 text-sm mb-1">
            <MapPin className="w-4 h-4" />
            <span>Lahore, Pakistan</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Assalam-o-Alaikum</h1>
          <p className="text-sm text-slate-400">Ahmed's Dream House</p>
        </div>
        <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-full flex items-center justify-center">
          <Home className="w-6 h-6 text-white" />
        </div>
      </div>

      <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-emerald-400 font-medium">Overall Progress</span>
          <span className="text-2xl font-bold text-white">42%</span>
        </div>
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
            initial={{ width: 0 }}
            animate={{ width: '42%' }}
            transition={{ duration: 1 }}
          />
        </div>
        <div className="grid grid-cols-3 gap-2 mt-3 text-xs">
          <div className="text-center"><div className="text-white font-bold">23</div><div className="text-slate-400">Days</div></div>
          <div className="text-center"><div className="text-white font-bold">₨4.2L</div><div className="text-slate-400">Spent</div></div>
          <div className="text-center"><div className="text-white font-bold">₨5.8L</div><div className="text-slate-400">Budget</div></div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {['Log Delivery', 'Add Photos', 'Check Prices', 'View Alerts'].map((action, i) => (
          <button key={action} className="bg-white/10 border border-white/20 rounded-xl p-4 text-left hover:bg-white/20 transition-all">
            <div className="text-sm font-medium text-white">{action}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

function EstimatorScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-1">Material Estimate</h2>
        <p className="text-sm text-slate-400">10 Marla • Double Story • Lahore</p>
      </div>

      <div className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-2xl p-6 text-center">
        <div className="text-4xl font-bold text-white mb-2">₨ 52.4 Lakh</div>
        <div className="text-sm text-emerald-400">Estimated Total Cost</div>
      </div>

      <div className="space-y-3">
        {['Cement Bags', 'Steel Bars', 'Bricks', 'Sand'].map((item, i) => (
          <div key={item} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
            <div>
              <div className="text-white font-medium">{item}</div>
              <div className="text-xs text-slate-400">1,850 bags</div>
            </div>
            <div className="text-emerald-400 font-semibold">₨ 8.5L</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DeliveryScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Log Delivery</h2>
        <div className="text-xs text-emerald-400">Offline Mode</div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-sm text-slate-400 mb-2 block">Material Type</label>
          <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
            <option>Cement Bags</option>
            <option>Steel Bars</option>
            <option>Bricks</option>
          </select>
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">Quantity</label>
          <input type="number" placeholder="Enter quantity" className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white placeholder-slate-500" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button className="aspect-square bg-white/10 border-2 border-dashed border-white/20 rounded-xl flex flex-col items-center justify-center">
            <Camera className="w-8 h-8 text-slate-400 mb-2" />
            <span className="text-xs text-slate-400">Stack Photo</span>
          </button>
          <button className="aspect-square bg-white/10 border-2 border-dashed border-white/20 rounded-xl flex flex-col items-center justify-center">
            <Package className="w-8 h-8 text-slate-400 mb-2" />
            <span className="text-xs text-slate-400">Invoice</span>
          </button>
        </div>
      </div>

      <button className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold">
        Save Delivery
      </button>
    </div>
  );
}

function PriceTrackerScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Live Prices</h2>
        <div className="text-xs text-emerald-400">Updated 2h ago</div>
      </div>

      <div className="space-y-3">
        {[
          { name: 'Lucky Cement', price: 'Rs 1,450', change: '-2.3%' },
          { name: 'Bestway Cement', price: 'Rs 1,420', change: '-1.8%' },
          { name: 'Amreli Steel', price: 'Rs 285,000/ton', change: '-3.2%' }
        ].map((item, i) => (
          <div key={item.name} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
            <div>
              <div className="text-white font-medium">{item.name}</div>
              <div className="text-xs text-slate-400">{item.price}</div>
            </div>
            <div className="px-3 py-1 bg-emerald-500/20 rounded-full text-xs font-semibold text-emerald-400">
              {item.change}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}