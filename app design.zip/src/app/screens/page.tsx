'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { Home, Package, Camera, TrendingDown, Bell, MapPin, CheckCircle2, AlertTriangle, Upload, Shield } from 'lucide-react';

type ScreenType = 'onboarding' | 'dashboard' | 'estimate' | 'delivery' | 'pricing' | 'alerts';

const screens = [
  { id: 'onboarding' as ScreenType, label: 'Onboarding', icon: Home, color: 'from-blue-500 to-cyan-500' },
  { id: 'dashboard' as ScreenType, label: 'Dashboard', icon: Home, color: 'from-green-500 to-emerald-500' },
  { id: 'estimate' as ScreenType, label: 'Estimator', icon: Package, color: 'from-purple-500 to-pink-500' },
  { id: 'delivery' as ScreenType, label: 'Delivery Log', icon: Camera, color: 'from-orange-500 to-red-500' },
  { id: 'pricing' as ScreenType, label: 'Price Tracker', icon: TrendingDown, color: 'from-indigo-500 to-purple-500' },
  { id: 'alerts' as ScreenType, label: 'Alerts', icon: Bell, color: 'from-rose-500 to-pink-500' },
];

export default function ScreensPage() {
  const [activeScreen, setActiveScreen] = useState<ScreenType>('dashboard');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-6 py-20">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <motion.div
            className="inline-flex items-center space-x-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Home className="w-4 h-4 text-green-400" />
            <span className="text-sm text-green-400 font-medium">Interactive Screens</span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-green-300 via-emerald-300 to-teal-300 bg-clip-text text-transparent">
            App Screens
          </h1>
          
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Interactive mockups showcasing key user interfaces
          </p>
        </div>

        {/* Screen Selector */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {screens.map((screen) => (
            <motion.button
              key={screen.id}
              onClick={() => setActiveScreen(screen.id)}
              className={`px-4 py-2 rounded-xl border transition-all ${
                activeScreen === screen.id
                  ? 'bg-white/10 border-white/20 shadow-lg'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="flex items-center space-x-2">
                <screen.icon className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-medium text-white">{screen.label}</span>
              </div>
            </motion.button>
          ))}
        </div>

        {/* Phone Mockup Container */}
        <div className="flex justify-center">
          <motion.div
            className="relative"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {/* Phone Frame */}
            <div className="relative bg-slate-900 rounded-[3rem] p-3 shadow-2xl shadow-emerald-500/20 border-4 border-slate-800">
              {/* Notch */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-20" />
              
              {/* Screen Content */}
              <div className="bg-slate-950 rounded-[2.5rem] overflow-hidden h-[600px] w-[320px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeScreen}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="h-full overflow-y-auto"
                  >
                    {activeScreen === 'dashboard' && <DashboardScreen />}
                    {activeScreen === 'onboarding' && <OnboardingScreen />}
                    {activeScreen === 'estimate' && <EstimateScreen />}
                    {activeScreen === 'delivery' && <DeliveryScreen />}
                    {activeScreen === 'pricing' && <PricingScreen />}
                    {activeScreen === 'alerts' && <AlertsScreen />}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

// Screen Components
function DashboardScreen() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2 text-emerald-400 text-sm mb-1">
            <MapPin className="w-4 h-4" />
            <span>Lahore, Pakistan</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Assalam-o-Alaikum</h1>
          <p className="text-sm text-slate-400">Ahmed's Dream House</p>
        </div>
        <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-full flex items-center justify-center">
          <Home className="w-6 h-6 text-white" />
        </div>
      </div>

      {/* Progress Card */}
      <motion.div
        className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-2xl p-4"
        whileHover={{ scale: 1.02 }}
      >
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-emerald-400 font-medium">Overall Progress</span>
          <span className="text-2xl font-bold text-white">42%</span>
        </div>
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
            initial={{ width: 0 }}
            animate={{ width: '42%' }}
            transition={{ duration: 1, delay: 0.2 }}
          />
        </div>
        <div className="grid grid-cols-3 gap-2 mt-3 text-xs">
          <div className="text-center"><div className="text-white font-bold">23</div><div className="text-slate-400">Days</div></div>
          <div className="text-center"><div className="text-white font-bold">₨4.2L</div><div className="text-slate-400">Spent</div></div>
          <div className="text-center"><div className="text-white font-bold">₨5.8L</div><div className="text-slate-400">Budget</div></div>
        </div>
      </motion.div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        {['Log Delivery', 'Add Photos', 'Check Prices', 'View Alerts'].map((action, i) => (
          <motion.button
            key={action}
            className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-xl p-4 text-left hover:from-emerald-500/30 transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="text-sm font-medium text-white">{action}</div>
          </motion.button>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-400">Recent Activity</h3>
        {['50 cement bags delivered', 'Progress photos uploaded', 'Foundation milestone completed'].map((item, i) => (
          <motion.div
            key={i}
            className="flex items-center space-x-3 p-3 bg-white/5 rounded-xl"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="flex-1">
              <div className="text-sm text-white">{item}</div>
              <div className="text-xs text-slate-500">{i === 0 ? '2 hours ago' : i === 1 ? '5 hours ago' : '1 day ago'}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function OnboardingScreen() {
  return (
    <div className="p-6 space-y-6 flex flex-col justify-center h-full">
      <div className="text-center space-y-4">
        <motion.div
          className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-3xl flex items-center justify-center mx-auto"
          animate={{ rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Home className="w-10 h-10 text-white" />
        </motion.div>
        
        <h2 className="text-2xl font-bold text-white">Apna Ghar Banaye</h2>
        <p className="text-slate-400">Let's setup your dream house project</p>
      </div>

      <div className="space-y-4">
        {['Plot Size', 'Number of Floors', 'House Type', 'City'].map((label, i) => (
          <div key={label}>
            <label className="text-sm text-slate-400 mb-2 block">{label}</label>
            <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
              {i === 0 ? ['5 Marla', '10 Marla', '1 Kanal'] : 
               i === 1 ? ['1', '2', '3'] : 
               i === 2 ? ['Standard', 'Premium', 'Luxury'] : 
               ['Lahore', 'Karachi', 'Islamabad']}
            </select>
          </div>
        ))}
      </div>

      <motion.button
        className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Calculate Estimate
      </motion.button>
    </div>
  );
}

function EstimateScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-1">Material Estimate</h2>
        <p className="text-sm text-slate-400">10 Marla • Double Story • Lahore</p>
      </div>

      <motion.div
        className="bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-2xl p-6 text-center"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <div className="text-4xl font-bold text-white mb-2">₨ 52.4 Lakh</div>
        <div className="text-sm text-emerald-400">Estimated Total Cost</div>
      </motion.div>

      <div className="space-y-3">
        {[
          { name: 'Cement Bags', qty: '1,850', price: '₨ 8.5L' },
          { name: 'Steel Bars', qty: '12.5', price: '₨ 18.2L' },
          { name: 'Bricks', qty: '85,000', price: '₨ 12.8L' },
          { name: 'Sand', qty: '420', price: '₨ 6.2L' }
        ].map((item, i) => (
          <motion.div
            key={item.name}
            className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div>
              <div className="text-white font-medium">{item.name}</div>
              <div className="text-xs text-slate-400">{item.qty} {item.name === 'Steel Bars' ? 'tons' : item.name === 'Bricks' ? 'pcs' : 'bags'}</div>
            </div>
            <div className="text-emerald-400 font-semibold">{item.price}</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function DeliveryScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Log Delivery</h2>
        <div className="text-xs text-emerald-400">Offline Mode</div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-sm text-slate-400 mb-2 block">Material Type</label>
          <select className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white">
            <option>Cement Bags</option>
            <option>Steel Bars</option>
            <option>Bricks</option>
          </select>
        </div>

        <div>
          <label className="text-sm text-slate-400 mb-2 block">Quantity</label>
          <input type="number" placeholder="Enter quantity" className="w-full bg-white/10 border border-white/20 rounded-xl p-3 text-white placeholder-slate-500" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button className="aspect-square bg-white/10 border-2 border-dashed border-white/20 rounded-xl flex flex-col items-center justify-center">
            <Camera className="w-8 h-8 text-slate-400 mb-2" />
            <span className="text-xs text-slate-400">Stack Photo</span>
          </button>
          <button className="aspect-square bg-white/10 border-2 border-dashed border-white/20 rounded-xl flex flex-col items-center justify-center">
            <Upload className="w-8 h-8 text-slate-400 mb-2" />
            <span className="text-xs text-slate-400">Invoice</span>
          </button>
        </div>

        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex items-start space-x-2">
          <MapPin className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-sm text-emerald-400 font-medium">GPS Location Added</div>
            <div className="text-xs text-slate-400">31.5204° N, 74.3587° E</div>
          </div>
        </div>
      </div>

      <motion.button
        className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Save Delivery
      </motion.button>
    </div>
  );
}

function PricingScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Live Prices</h2>
        <div className="text-xs text-emerald-400">Updated 2h ago</div>
      </div>

      <div className="space-y-3">
        {[
          { name: 'Lucky Cement', price: 'Rs 1,450', change: '-2.3%' },
          { name: 'Bestway Cement', price: 'Rs 1,420', change: '-1.8%' },
          { name: 'Amreli Steel', price: 'Rs 285,000/ton', change: '-3.2%' }
        ].map((item, i) => (
          <motion.div
            key={item.name}
            className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div>
              <div className="text-white font-medium">{item.name}</div>
              <div className="text-xs text-slate-400">{item.price}</div>
            </div>
            <div className="px-3 py-1 bg-emerald-500/20 rounded-full text-xs font-semibold text-emerald-400">
              {item.change}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function AlertsScreen() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Notifications</h2>
        <div className="w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
      </div>

      <div className="space-y-3">
        {[
          { type: 'warning', icon: AlertTriangle, title: 'Material Discrepancy', desc: '15 cement bags variance detected', action: 'Review Details', color: 'from-orange-500 to-red-500' },
          { type: 'success', icon: TrendingDown, title: 'Price Drop Alert', desc: 'Lucky Cement price dropped', action: 'View Prices', color: 'from-green-500 to-emerald-500' },
          { type: 'info', icon: Camera, title: 'Progress Photos', desc: 'Contractor uploaded 5 photos', action: 'View Gallery', color: 'from-blue-500 to-cyan-500' }
        ].map((alert, i) => (
          <motion.div
            key={i}
            className="bg-white/5 rounded-xl p-4 space-y-3"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="flex items-start space-x-3">
              <div className={`w-10 h-10 bg-gradient-to-br ${alert.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                <alert.icon className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <div className="text-white font-medium mb-1">{alert.title}</div>
                <div className="text-xs text-slate-400">{alert.desc}</div>
              </div>
            </div>
            <button className={`w-full py-2 bg-gradient-to-r ${alert.color} rounded-lg text-white text-sm font-medium`}>
              {alert.action}
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}