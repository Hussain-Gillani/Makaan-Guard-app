'use client';

import { motion } from 'framer-motion';
import { Shield, Target, Heart, Zap, Globe, Users, Package, DollarSign } from 'lucide-react';

const scopes = [
  {
    id: 1,
    title: 'Project Setup & Smart Estimator',
    description: 'Guided wizard with 7–8 simple questions. Instantly generates accurate material quantities and city-specific market rates.',
    feel: 'Exciting and reassuring',
    keyFeatures: ['Plot size calculator (marla/kanal)', 'Multi-floor planning', 'Animated house visualization', 'Real-time cost estimation'],
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 2,
    title: 'Live Material Rate Tracker & Alerts',
    description: 'Daily updated prices for cement, steel, sand, bricks, etc. with trend arrows and price-drop alerts.',
    feel: 'Like a knowledgeable friend',
    keyFeatures: ['City-specific pricing', 'Trend analysis', 'Smart alerts', 'WhatsApp notifications'],
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 3,
    title: 'Material Delivery Logging',
    description: 'Photo-first flow with voice input support in Urdu. Works fully offline with GPS tagging.',
    feel: 'Quick and official',
    keyFeatures: ['30-second logging', 'Photo verification', 'Voice input (Urdu)', 'Offline support'],
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: 4,
    title: 'Daily Usage Logging & Anti-Theft Engine',
    description: 'Contractor logs daily usage. Background engine compares deliveries vs. usage vs. estimates.',
    feel: 'Quietly vigilant watchdog',
    keyFeatures: ['Voice usage logging', 'Smart discrepancy detection', 'Private owner alerts', 'Respectful notifications'],
    color: 'from-orange-500 to-red-500',
  },
  {
    id: 5,
    title: 'Progress Photo Journal & Overseas Dashboard',
    description: 'Daily geo-tagged photos with voice captions. Weekly collages for overseas users.',
    feel: 'Window into your home',
    keyFeatures: ['Daily photo digests', 'Weekly collages', 'One-tap video calls', 'English-first for diaspora'],
    color: 'from-indigo-500 to-purple-500',
  },
  {
    id: 6,
    title: 'Premium Monitoring, Payments & Supplier Connections',
    description: 'Subscription unlocks milestone verification, direct payments, and one-tap supplier ordering.',
    feel: 'Professional engineer watching',
    keyFeatures: ['Milestone verification', 'JazzCash/Easypaisa integration', 'Trusted supplier network', '$15-25/month'],
    color: 'from-teal-500 to-cyan-500',
  },
];

export default function PRDPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-6 py-20">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6 mb-16"
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span className="text-sm text-emerald-400 font-medium">Product Requirements Document</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-emerald-300 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
            MakanGuard
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto">
            A calm, vigilant digital guardian for Pakistani homeowners building their dream house
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {[
            { label: 'Houses Built Annually', value: '800K-1M', icon: Users },
            { label: 'Average Budget Loss', value: '25-40%', icon: DollarSign },
            { label: 'Overseas Pakistanis', value: '10M+', icon: Globe },
            { label: 'Annual Remittances', value: '$32-35B', icon: DollarSign }
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all group"
            >
              <div className="flex items-center justify-between mb-4">
                <stat.icon className="w-8 h-8 text-emerald-400 group-hover:scale-110 transition-transform" />
                <motion.div
                  className="w-2 h-2 bg-emerald-500 rounded-full"
                  animate={{ scale: [1, 1.5, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
                />
              </div>
              <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-sm text-slate-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Vision Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-3xl p-8 md:p-12 mb-20"
        >
          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold text-white">What</h3>
              <p className="text-slate-300">
                A digital guardian calculating exact material requirements, tracking every delivery, 
                and providing peaceful remote visibility to stop 25–40% budget losses.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 bg-teal-500/20 rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-teal-400" />
              </div>
              <h3 className="text-xl font-bold text-white">Why</h3>
              <p className="text-slate-300">
                800K-1M houses built yearly in Pakistan with 25-40% overruns due to theft and fraud. 
                Overseas Pakistanis have zero visibility into their largest investment.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-12 h-12 bg-cyan-500/20 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-xl font-bold text-white">Feel</h3>
              <p className="text-slate-300">
                Like a trusted elder brother or honest civil engineer friend — protective, calm, and respectful. 
                Empowers rather than overwhelms.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Scopes */}
        <div className="space-y-6">
          <div className="text-center space-y-2 mb-12">
            <h2 className="text-3xl font-bold text-white">Six Sequential Scopes</h2>
            <p className="text-slate-400">Each delivers standalone value and builds habit</p>
          </div>

          <div className="grid gap-6">
            {scopes.map((scope, index) => (
              <motion.div
                key={scope.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group relative"
              >
                <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                  <div className="flex items-start space-x-4">
                    <div className={`flex-shrink-0 w-16 h-16 bg-gradient-to-br ${scope.color} rounded-xl flex items-center justify-center shadow-lg`}>
                      <span className="text-2xl font-bold text-white">{scope.id}</span>
                    </div>

                    <div className="flex-1 space-y-3">
                      <div className="flex items-center space-x-3">
                        <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-medium text-emerald-400">
                          Scope {scope.id}
                        </span>
                        <h3 className="text-xl font-bold text-white">{scope.title}</h3>
                      </div>

                      <p className="text-slate-300">{scope.description}</p>

                      <div className="grid md:grid-cols-2 gap-2">
                        {scope.keyFeatures.map((feature, i) => (
                          <div key={i} className="flex items-center space-x-2 text-sm text-slate-400">
                            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                            <span>{feature}</span>
                          </div>
                        ))}
                      </div>

                      <div className="inline-flex items-center space-x-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
                        <Heart className="w-4 h-4 text-emerald-400" />
                        <span className="text-sm text-emerald-400 font-medium">{scope.feel}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}