'use client';

import { motion } from 'framer-motion';
import { Crown, Star, CreditCard, Smartphone, Shield, CheckCircle2, Copy, ExternalLink } from 'lucide-react';
import { useState } from 'react';

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    period: 'month',
    description: 'Perfect for getting started',
    icon: Star,
    color: 'from-blue-500 to-cyan-500',
    features: [
      '1 active project',
      'Basic material estimator',
      '2 AI estimates (one-time)',
      '20 chatbot messages (one-time)',
      '5 photo analyses (one-time)',
      'Basic delivery logging',
      'Price viewing only',
      'Email support'
    ]
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 5999,
    period: 'month',
    description: 'Full protection with AI',
    icon: Crown,
    color: 'from-purple-500 to-pink-500',
    popular: true,
    features: [
      'Unlimited projects',
      'All 8 AI features unlocked',
      'Unlimited AI estimates',
      'Real-time theft detection',
      'Unlimited AI photo analysis',
      'AI price predictions',
      'Milestone verification',
      'JazzCash/Easypaisa payments',
      'Priority 24/7 support'
    ],
    savings: 'Save Rs. 50,000+ on theft prevention'
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 15999,
    period: 'month',
    description: 'For construction companies',
    icon: Shield,
    color: 'from-orange-500 to-red-500',
    features: [
      'Everything in Premium',
      'Unlimited team members',
      'Multi-project dashboard',
      'Custom AI model training',
      'API access',
      'Dedicated account manager'
    ],
    savings: 'Save Rs. 100,000+ annually'
  }
];

const paymentMethods = [
  {
    id: 'nayapay',
    name: 'NayaPay',
    description: 'Direct bank transfer',
    icon: Smartphone,
    recommended: true,
    details: {
      accountName: 'Hussain Gillani',
      accountNumber: '+92 300061971',
    }
  },
  {
    id: 'jazzcash',
    name: 'JazzCash',
    description: 'Mobile wallet payment',
    icon: Smartphone,
    details: {
      accountNumber: '+92 300061971',
    }
  },
  {
    id: 'easypaisa',
    name: 'Easypaisa',
    description: 'Mobile wallet payment',
    icon: Smartphone,
    details: {
      accountNumber: '+92 300061971',
    }
  }
];

export default function PricingPage() {
  const [selectedPlan, setSelectedPlan] = useState('premium');
  const [selectedMethod, setSelectedMethod] = useState('nayapay');
  const [copied, setCopied] = useState(false);

  const plan = plans.find(p => p.id === selectedPlan) || plans[1];
  const method = paymentMethods.find(m => m.id === selectedMethod) || paymentMethods[0];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-6 py-20">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <motion.div
            className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span className="text-sm text-emerald-400 font-medium">Pricing & Payment</span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-emerald-300 via-teal-300 to-cyan-300 bg-clip-text text-transparent">
            Choose Your Plan
          </h1>
          
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Protect your construction investment with AI-powered monitoring and anti-theft features
          </p>
        </div>

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {plans.map((planItem, index) => (
            <motion.button
              key={planItem.id}
              onClick={() => setSelectedPlan(planItem.id)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative p-6 rounded-3xl border transition-all text-left ${
                selectedPlan === planItem.id
                  ? 'bg-white/10 border-white/20 shadow-2xl scale-105'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              } ${planItem.popular ? 'md:scale-110 z-10' : ''}`}
              whileHover={{ scale: planItem.popular ? 1.12 : 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {planItem.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="px-4 py-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full text-xs font-semibold text-white flex items-center space-x-1">
                    <Star className="w-3 h-3" />
                    <span>MOST POPULAR</span>
                  </div>
                </div>
              )}

              <div className={`w-14 h-14 bg-gradient-to-br ${planItem.color} rounded-2xl flex items-center justify-center mb-4`}>
                <planItem.icon className="w-7 h-7 text-white" />
              </div>

              <h3 className="text-2xl font-bold text-white mb-2">{planItem.name}</h3>
              <p className="text-sm text-slate-400 mb-4">{planItem.description}</p>

              <div className="mb-6">
                <div className="flex items-baseline space-x-1">
                  <span className="text-4xl font-bold text-white">{planItem.price === 0 ? 'Free' : `Rs.${planItem.price.toLocaleString()}`}</span>
                  {planItem.price > 0 && <span className="text-slate-400">/{planItem.period}</span>}
                </div>
                {planItem.savings && (
                  <div className="text-sm text-emerald-400 mt-1">{planItem.savings}</div>
                )}
              </div>

              <div className="space-y-2 mb-6">
                {planItem.features.map((feature, i) => (
                  <div key={i} className="flex items-start space-x-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-300">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.button>
          ))}
        </div>

        {/* Payment Details for Premium/Enterprise */}
        {selectedPlan !== 'free' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 mb-16"
          >
            <h2 className="text-3xl font-bold text-white mb-8 text-center">Payment Information</h2>

            {/* Payment Method Selection */}
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              {paymentMethods.map((methodItem) => (
                <button
                  key={methodItem.id}
                  onClick={() => setSelectedMethod(methodItem.id)}
                  className={`p-4 rounded-2xl border transition-all ${
                    selectedMethod === methodItem.id
                      ? 'bg-white/10 border-emerald-500/50 shadow-lg'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      selectedMethod === methodItem.id ? 'bg-emerald-500/20' : 'bg-white/10'
                    }`}>
                      <methodItem.icon className={`w-6 h-6 ${
                        selectedMethod === methodItem.id ? 'text-emerald-400' : 'text-slate-400'
                      }`} />
                    </div>
                    <div className="flex-1 text-left">
                      <div className="flex items-center space-x-2">
                        <span className="text-white font-semibold">{methodItem.name}</span>
                        {methodItem.recommended && (
                          <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/30 rounded text-xs text-emerald-400">
                            Recommended
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">{methodItem.description}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Payment Details */}
            <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/30 rounded-2xl p-8 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Transfer To:</h3>
                <Shield className="w-6 h-6 text-emerald-400" />
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Account Name</label>
                  <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
                    <span className="text-white font-semibold">{method.details.accountName || 'Hussain Gillani'}</span>
                    <button
                      onClick={() => copyToClipboard(method.details.accountName || 'Hussain Gillani')}
                      className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                    >
                      {copied ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-slate-400" />
                      )}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1 block">Mobile Number</label>
                  <div className="flex items-center justify-between p-3 bg-white/10 rounded-lg">
                    <span className="text-white font-mono text-lg">{method.details.accountNumber}</span>
                    <button
                      onClick={() => copyToClipboard(method.details.accountNumber)}
                      className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                    >
                      {copied ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4 text-slate-400" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <motion.button
                className="flex-1 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl text-white font-semibold shadow-lg shadow-emerald-500/50"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => window.open('https://wa.me/923000619771?text=Hi! I want to activate MakanGuard Premium', '_blank')}
              >
                <div className="flex items-center justify-center space-x-2">
                  <ExternalLink className="w-5 h-5" />
                  <span>Send Payment Proof via WhatsApp</span>
                </div>
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Money-Back Guarantee */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-3xl p-8 text-center"
        >
          <Shield className="w-16 h-16 text-blue-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-3">30-Day Money-Back Guarantee</h3>
          <p className="text-slate-300 max-w-2xl mx-auto">
            If MakanGuard doesn't help you save money or prevent theft in the first 30 days, we'll refund 100% of your payment. No questions asked.
          </p>
        </motion.div>
      </div>
    </div>
  );
}