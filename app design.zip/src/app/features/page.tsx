'use client';

import { motion } from 'framer-motion';
import { Brain, MessageSquare, Shield, Eye, TrendingUp, Cpu, Lock, Sparkles, DollarSign, CheckCircle2, Zap } from 'lucide-react';
import { useState } from 'react';

const aiFeatures = [
  {
    id: 'ai-estimator',
    title: 'AI-Powered Material Estimator',
    description: 'Upload your floor plan and get instant AI-generated material quantities using computer vision',
    icon: Brain,
    color: 'from-purple-500 to-pink-500',
    accuracy: '98%',
    pricing: 'Rs. 2,500/month'
  },
  {
    id: 'ai-chatbot',
    title: 'Urdu/English Construction Advisor',
    description: '24/7 AI chatbot answering construction questions and material advice',
    icon: MessageSquare,
    color: 'from-blue-500 to-cyan-500',
    accuracy: '95%',
    pricing: 'Rs. 1,800/month'
  },
  {
    id: 'fraud-detection',
    title: 'AI Theft Detection Engine',
    description: 'Machine learning detecting material discrepancies and potential fraud automatically',
    icon: Shield,
    color: 'from-red-500 to-orange-500',
    accuracy: '92%',
    pricing: 'Rs. 3,500/month'
  },
  {
    id: 'photo-analysis',
    title: 'AI Construction Progress Analyzer',
    description: 'Computer vision analyzing progress photos to verify work completion',
    icon: Eye,
    color: 'from-green-500 to-emerald-500',
    accuracy: '94%',
    pricing: 'Rs. 2,800/month'
  },
  {
    id: 'price-predictor',
    title: 'AI Price Prediction & Optimizer',
    description: 'Machine learning predicting material price movements and recommending optimal purchase timing',
    icon: TrendingUp,
    color: 'from-amber-500 to-yellow-500',
    accuracy: '89%',
    pricing: 'Rs. 2,200/month'
  },
  {
    id: 'smart-scheduler',
    title: 'AI Construction Scheduler',
    description: 'AI-powered project scheduling optimizing timelines and predicting delays',
    icon: Cpu,
    color: 'from-indigo-500 to-purple-500',
    accuracy: '91%',
    pricing: 'Rs. 2,500/month'
  },
  {
    id: 'document-ai',
    title: 'AI Document & Contract Analyzer',
    description: 'Automatically review contracts and invoices to flag issues and ensure compliance',
    icon: Lock,
    color: 'from-rose-500 to-pink-500',
    accuracy: '96%',
    pricing: 'Rs. 2,400/month'
  },
  {
    id: 'voice-assistant',
    title: 'AI Voice Assistant (Urdu)',
    description: 'Hands-free voice assistant for contractors on-site to log data and get guidance',
    icon: Sparkles,
    color: 'from-teal-500 to-cyan-500',
    accuracy: '93%',
    pricing: 'Rs. 1,800/month'
  }
];

export default function FeaturesPage() {
  const [selectedFeature, setSelectedFeature] = useState(aiFeatures[0].id);

  const selected = aiFeatures.find(f => f.id === selectedFeature) || aiFeatures[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto px-6 py-20">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <motion.div
            className="inline-flex items-center space-x-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-purple-400 font-medium">Premium AI-Powered Features</span>
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-300 via-pink-300 to-rose-300 bg-clip-text text-transparent">
            Artificial Intelligence
          </h1>
          
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            8 powerful AI features leveraging enterprise models to save money and prevent fraud
          </p>
        </div>

        {/* AI Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {aiFeatures.map((feature, index) => (
            <motion.button
              key={feature.id}
              onClick={() => setSelectedFeature(feature.id)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`p-4 rounded-2xl border transition-all text-left ${
                selectedFeature === feature.id
                  ? 'bg-white/10 border-white/20 shadow-xl'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-3`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-sm font-bold text-white mb-1">{feature.title}</h3>
              <p className="text-xs text-slate-400">{feature.pricing}</p>
            </motion.button>
          ))}
        </div>

        {/* Selected Feature Detail */}
        <motion.div
          key={selectedFeature}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 mb-16"
        >
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-start space-x-4">
              <div className={`w-16 h-16 bg-gradient-to-br ${selected.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                <selected.icon className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-white mb-2">{selected.title}</h2>
                <p className="text-lg text-slate-300">{selected.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-slate-400 mb-1">Accuracy</div>
              <div className="text-3xl font-bold text-emerald-400">{selected.accuracy}</div>
            </div>
          </div>

          <div className="inline-flex items-center space-x-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span className="text-sm text-emerald-400 font-medium">Premium Feature - {selected.pricing}</span>
          </div>
        </motion.div>

        {/* Value Proposition */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-3xl p-8 md:p-12 text-center"
        >
          <h2 className="text-3xl font-bold text-white mb-8">Why Premium AI Features Are Worth It</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: 'Save Rs. 50,000+', desc: 'AI theft detection prevents material losses', icon: DollarSign, value: '10x ROI' },
              { title: 'Expert-Level Advice', desc: '24/7 AI trained on thousands of projects', icon: Zap, value: 'Always Available' },
              { title: 'Peace of Mind', desc: 'Continuous monitoring and instant alerts', icon: Shield, value: '24/7 Protection' }
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="text-center space-y-3"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto">
                  <item.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-amber-400">{item.value}</div>
                <h4 className="text-lg font-semibold text-white">{item.title}</h4>
                <p className="text-sm text-slate-400">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}